import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, loginUserSchema, insertSocialAccountSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "identity-theft-detection-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Mock handlers for social login
  const handleSocialLogin = async (req: Request, res: Response, provider: string) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" });
    }
    
    try {
      // Check if we already have this social account
      const providerId = `${provider}_${username}`;
      const socialAccounts = await storage.getSocialAccountsByProviderId(providerId, provider);
      
      let user: SelectUser | undefined;
      
      // If we have this account, get the associated user
      if (socialAccounts && socialAccounts.length > 0) {
        user = await storage.getUser(socialAccounts[0].userId);
      }
      
      // If no user found, create a new one
      if (!user) {
        const randomUsername = `${provider.substring(0, 2)}_${randomBytes(4).toString("hex")}`;
        
        user = await storage.createUser({
          username: randomUsername,
          password: await hashPassword(password),
          fullName: username, // Using username as fullname for simplicity
          email: `${username}@${provider}.com`,
        });
        
        // Store the social account details
        await storage.createSocialAccount({
          userId: user.id,
          provider,
          providerId,
          username,
          profileUrl: `https://${provider}.com/${username}`,
          accessToken: randomBytes(16).toString("hex"),
          refreshToken: randomBytes(16).toString("hex"),
        });
      }
      
      // Login the user
      req.login(user, async (loginErr) => {
        if (loginErr) {
          return res.status(500).json({ message: "Login error" });
        }
        
        // Record login activity
        const session = await storage.createSession({
          userId: user!.id,
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"] || "",
          browser: "Unknown",
          os: "Unknown",
          device: "Unknown",
          location: "Unknown",
        });
        
        await storage.createActivity({
          userId: user!.id,
          sessionId: session.id,
          activityType: "login",
          details: `User logged in via ${provider}`,
        });
        
        return res.status(200).json(user);
      });
    } catch (error) {
      console.error(`${provider} login error:`, error);
      return res.status(500).json({ message: `${provider} login failed` });
    }
  };

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
      });

      req.login(user, (err) => {
        if (err) return next(err);
        
        // Record login activity
        const session = storage.createSession({
          userId: user.id,
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"] || "",
          browser: "Unknown", // In a real app, parse user agent
          os: "Unknown", // In a real app, parse user agent
          device: "Unknown", // In a real app, parse user agent
          location: "Unknown", // In a real app, use geolocation service
        });
        
        // Create initial device record
        const device = storage.createDevice({
          userId: user.id,
          deviceName: "Unknown Device",
          deviceType: "Unknown",
          isPrimary: true,
          isTrusted: true,
        });
        
        res.status(201).json(user);
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    try {
      // Validate login data
      const loginData = loginUserSchema.parse(req.body);
      
      passport.authenticate("local", (err: Error, user: SelectUser) => {
        if (err) {
          return next(err);
        }
        if (!user) {
          return res.status(401).json({ message: "Invalid username or password" });
        }
        
        req.login(user, async (loginErr) => {
          if (loginErr) {
            return next(loginErr);
          }
          
          // Record login activity
          const session = await storage.createSession({
            userId: user.id,
            ipAddress: req.ip,
            userAgent: req.headers["user-agent"] || "",
            browser: "Unknown", // In a real app, parse user agent
            os: "Unknown", // In a real app, parse user agent
            device: "Unknown", // In a real app, parse user agent
            location: "Unknown", // In a real app, use geolocation service
          });
          
          // Record login activity
          await storage.createActivity({
            userId: user.id,
            sessionId: session.id,
            activityType: "login",
            details: "User logged in",
          });
          
          return res.status(200).json(user);
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  app.post("/api/logout", async (req, res, next) => {
    if (req.isAuthenticated()) {
      // Close active session if there is one
      if (req.user) {
        await storage.closeSession(req.user.id);
        
        // Record logout activity
        await storage.createActivity({
          userId: req.user.id,
          activityType: "logout",
          details: "User logged out",
        });
      }
      
      req.logout((err) => {
        if (err) return next(err);
        res.sendStatus(200);
      });
    } else {
      res.sendStatus(200);
    }
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
  
  // Social login routes - mock implementations that don't require real API credentials
  
  // Mock Facebook login
  app.post("/api/auth/facebook", (req, res) => {
    handleSocialLogin(req, res, "facebook");
  });
  
  // Mock Instagram login
  app.post("/api/auth/instagram", (req, res) => {
    handleSocialLogin(req, res, "instagram");
  });
  
  // Mock Snapchat login
  app.post("/api/auth/snapchat", (req, res) => {
    handleSocialLogin(req, res, "snapchat");
  });
  
  // Mock Gmail login
  app.post("/api/auth/gmail", (req, res) => {
    handleSocialLogin(req, res, "gmail");
  });
}
