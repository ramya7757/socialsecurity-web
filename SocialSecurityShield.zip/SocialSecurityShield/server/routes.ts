import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { anomalyDetector } from "./anomalyDetection";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Custom middleware to check authentication
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };
  
  // Admin middleware
  const isAdmin = (req: any, res: any, next: any) => {
    if (req.isAuthenticated() && req.user.role === "admin") {
      return next();
    }
    res.status(403).json({ message: "Forbidden - Admin access required" });
  };
  
  // User behavior tracking
  app.post("/api/activity", isAuthenticated, async (req, res, next) => {
    try {
      const { activityType, details } = req.body;
      const userId = req.user.id;
      
      // Get active session if any
      const userSessions = await storage.getUserSessions(userId);
      const activeSession = userSessions.find(session => session.isActive);
      
      const activity = await storage.createActivity({
        userId,
        sessionId: activeSession?.id,
        activityType,
        details,
      });
      
      // Run anomaly detection on recent activities
      const userActivities = await storage.getUserActivities(userId);
      const anomalies = anomalyDetector.detectActivityAnomalies(userActivities);
      
      // Store any detected anomalies
      for (const anomaly of anomalies) {
        await storage.createAnomaly(anomaly);
      }
      
      res.status(201).json(activity);
    } catch (error) {
      next(error);
    }
  });
  
  // Get user's behavior summary
  app.get("/api/user/behavior", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      const sessions = await storage.getUserSessions(userId);
      const activities = await storage.getUserActivities(userId);
      const devices = await storage.getUserDevices(userId);
      
      // Calculate metrics
      const loginCount = sessions.length;
      const deviceCount = devices.length;
      
      // Calculate average session duration
      const completedSessions = sessions.filter(session => !session.isActive && session.duration);
      let avgSessionDuration = 0;
      
      if (completedSessions.length > 0) {
        const totalDuration = completedSessions.reduce((sum, session) => sum + (session.duration || 0), 0);
        avgSessionDuration = totalDuration / completedSessions.length / 3600; // Convert to hours
      }
      
      // Get primary device
      const primaryDevice = devices.find(device => device.isPrimary);
      
      res.json({
        loginCount,
        deviceCount,
        avgSessionDuration,
        primaryDevice,
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Get user's activity timeline
  app.get("/api/user/timeline", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const activities = await storage.getRecentActivities(userId, limit);
      
      res.json(activities);
    } catch (error) {
      next(error);
    }
  });
  
  // Get user's devices
  app.get("/api/user/devices", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const devices = await storage.getUserDevices(userId);
      
      res.json(devices);
    } catch (error) {
      next(error);
    }
  });
  
  // Update device
  app.patch("/api/user/devices/:id", isAuthenticated, async (req, res, next) => {
    try {
      const deviceId = parseInt(req.params.id);
      const userId = req.user.id;
      
      // Verify device belongs to user
      const devices = await storage.getUserDevices(userId);
      const device = devices.find(d => d.id === deviceId);
      
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      const updatedDevice = await storage.updateDevice(deviceId, req.body);
      res.json(updatedDevice);
    } catch (error) {
      next(error);
    }
  });
  
  // Get user's security score
  app.get("/api/user/security-score", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ score: user.securityScore });
    } catch (error) {
      next(error);
    }
  });
  
  // Get user's anomalies
  app.get("/api/user/anomalies", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const anomalies = await storage.getUserAnomalies(userId);
      
      res.json(anomalies);
    } catch (error) {
      next(error);
    }
  });
  
  // Resolve an anomaly
  app.patch("/api/user/anomalies/:id", isAuthenticated, async (req, res, next) => {
    try {
      const anomalyId = parseInt(req.params.id);
      const userId = req.user.id;
      
      // Verify anomaly belongs to user
      const anomalies = await storage.getUserAnomalies(userId);
      const anomaly = anomalies.find(a => a.id === anomalyId);
      
      if (!anomaly) {
        return res.status(404).json({ message: "Anomaly not found" });
      }
      
      const updatedAnomaly = await storage.updateAnomaly(anomalyId, { status: "resolved" });
      res.json(updatedAnomaly);
    } catch (error) {
      next(error);
    }
  });
  
  // Get educational resources
  app.get("/api/education", async (req, res, next) => {
    try {
      const resources = await storage.getAllEducationalResources();
      res.json(resources);
    } catch (error) {
      next(error);
    }
  });
  
  // Get specific educational resource
  app.get("/api/education/:id", async (req, res, next) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resource = await storage.getEducationalResource(resourceId);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      next(error);
    }
  });
  
  // Get simulation scenarios
  app.get("/api/simulation", async (req, res, next) => {
    try {
      const scenarios = await storage.getAllSimulationScenarios();
      res.json(scenarios);
    } catch (error) {
      next(error);
    }
  });
  
  // Get specific simulation scenario
  app.get("/api/simulation/:id", async (req, res, next) => {
    try {
      const scenarioId = parseInt(req.params.id);
      const scenario = await storage.getSimulationScenario(scenarioId);
      
      if (!scenario) {
        return res.status(404).json({ message: "Scenario not found" });
      }
      
      res.json(scenario);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin routes
  
  // Get all users (admin only)
  app.get("/api/admin/users", isAdmin, async (req, res, next) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      next(error);
    }
  });
  
  // Get user details (admin only)
  app.get("/api/admin/users/:id", isAdmin, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const sessions = await storage.getUserSessions(userId);
      const activities = await storage.getUserActivities(userId);
      const devices = await storage.getUserDevices(userId);
      const anomalies = await storage.getUserAnomalies(userId);
      
      res.json({
        user,
        sessions,
        activities,
        devices,
        anomalies,
      });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
