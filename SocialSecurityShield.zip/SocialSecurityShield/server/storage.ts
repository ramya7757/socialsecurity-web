import { users, type User, type InsertUser, userSessions, UserSession, InsertUserSession, userActivities, UserActivity, InsertUserActivity, devices, Device, InsertDevice, anomalies, Anomaly, InsertAnomaly, educationalResources, EducationalResource, InsertEducationalResource, simulationScenarios, SimulationScenario, InsertSimulationScenario, socialAccounts, SocialAccount, InsertSocialAccount } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { eq, desc, and } from "drizzle-orm";
import { db, pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Session operations
  createSession(session: InsertUserSession): Promise<UserSession>;
  getUserSessions(userId: number): Promise<UserSession[]>;
  getSession(id: number): Promise<UserSession | undefined>;
  closeSession(userId: number): Promise<void>;
  
  // Activity operations
  createActivity(activity: InsertUserActivity): Promise<UserActivity>;
  getUserActivities(userId: number): Promise<UserActivity[]>;
  getRecentActivities(userId: number, limit: number): Promise<UserActivity[]>;
  
  // Device operations
  createDevice(device: InsertDevice): Promise<Device>;
  getUserDevices(userId: number): Promise<Device[]>;
  updateDevice(id: number, data: Partial<Device>): Promise<Device | undefined>;
  
  // Anomaly operations
  createAnomaly(anomaly: InsertAnomaly): Promise<Anomaly>;
  getUserAnomalies(userId: number): Promise<Anomaly[]>;
  updateAnomaly(id: number, data: Partial<Anomaly>): Promise<Anomaly | undefined>;
  
  // Educational resources operations
  createEducationalResource(resource: InsertEducationalResource): Promise<EducationalResource>;
  getAllEducationalResources(): Promise<EducationalResource[]>;
  getEducationalResource(id: number): Promise<EducationalResource | undefined>;
  
  // Simulation operations
  createSimulationScenario(scenario: InsertSimulationScenario): Promise<SimulationScenario>;
  getAllSimulationScenarios(): Promise<SimulationScenario[]>;
  getSimulationScenario(id: number): Promise<SimulationScenario | undefined>;
  
  // Social accounts operations
  createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount>;
  getUserSocialAccounts(userId: number): Promise<SocialAccount[]>;
  getSocialAccountsByProviderId(providerId: string, provider: string): Promise<SocialAccount[]>;
  getSocialAccount(id: number): Promise<SocialAccount | undefined>;
  updateSocialAccount(id: number, data: Partial<SocialAccount>): Promise<SocialAccount | undefined>;
  
  // Session store
  sessionStore: any; // Changed from session.SessionStore
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sessions: Map<number, UserSession>;
  private activities: Map<number, UserActivity>;
  private devices: Map<number, Device>;
  private anomalyRecords: Map<number, Anomaly>;
  private educationalResources: Map<number, EducationalResource>;
  private simulationScenarios: Map<number, SimulationScenario>;
  private socialAccounts: Map<number, SocialAccount>;
  
  sessionStore: any;
  
  private userId: number = 1;
  private sessionId: number = 1;
  private activityId: number = 1;
  private deviceId: number = 1;
  private anomalyId: number = 1;
  private resourceId: number = 1;
  private scenarioId: number = 1;
  private socialAccountId: number = 1;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.activities = new Map();
    this.devices = new Map();
    this.anomalyRecords = new Map();
    this.educationalResources = new Map();
    this.simulationScenarios = new Map();
    this.socialAccounts = new Map();
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Create initial educational resources
    this.seedEducationalResources();
    
    // Create initial simulation scenarios
    this.seedSimulationScenarios();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser,
      fullName: insertUser.fullName ?? null, // Ensure fullName is not undefined
      email: insertUser.email ?? null, // Ensure email is not undefined
      id, 
      role: 'user',
      securityScore: 70,
      createdAt: now 
    };
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Session operations
  async createSession(sessionData: InsertUserSession): Promise<UserSession> {
    const id = this.sessionId++;
    const now = new Date();
    const session: UserSession = {
      ...sessionData,
      id,
      ipAddress: sessionData.ipAddress ?? null,
      userAgent: sessionData.userAgent ?? null,
      browser: sessionData.browser ?? null,
      os: sessionData.os ?? null,
      device: sessionData.device ?? null,
      location: sessionData.location ?? null,
      loginTime: now,
      logoutTime: null,
      duration: null,
      isActive: true
    };
    this.sessions.set(id, session);
    return session;
  }
  
  async getUserSessions(userId: number): Promise<UserSession[]> {
    return Array.from(this.sessions.values())
      .filter(session => session.userId === userId)
      .sort((a, b) => new Date(b.loginTime).getTime() - new Date(a.loginTime).getTime());
  }
  
  async getSession(id: number): Promise<UserSession | undefined> {
    return this.sessions.get(id);
  }
  
  async closeSession(userId: number): Promise<void> {
    const activeSessions = Array.from(this.sessions.values())
      .filter(session => session.userId === userId && session.isActive);
    
    for (const session of activeSessions) {
      const now = new Date();
      const loginTime = new Date(session.loginTime);
      const durationMs = now.getTime() - loginTime.getTime();
      const durationSeconds = Math.floor(durationMs / 1000);
      
      const updatedSession: UserSession = {
        ...session,
        logoutTime: now,
        duration: durationSeconds,
        isActive: false
      };
      
      this.sessions.set(session.id, updatedSession);
    }
  }
  
  // Activity operations
  async createActivity(activityData: InsertUserActivity): Promise<UserActivity> {
    const id = this.activityId++;
    const now = new Date();
    const activity: UserActivity = {
      ...activityData,
      id,
      sessionId: activityData.sessionId ?? null,
      details: activityData.details ?? null,
      timestamp: now
    };
    this.activities.set(id, activity);
    return activity;
  }
  
  async getUserActivities(userId: number): Promise<UserActivity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async getRecentActivities(userId: number, limit: number): Promise<UserActivity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  // Device operations
  async createDevice(deviceData: InsertDevice): Promise<Device> {
    const id = this.deviceId++;
    const now = new Date();
    const device: Device = {
      ...deviceData,
      id,
      isTrusted: deviceData.isTrusted ?? null,
      isPrimary: deviceData.isPrimary ?? null,
      lastActive: now
    };
    this.devices.set(id, device);
    return device;
  }
  
  async getUserDevices(userId: number): Promise<Device[]> {
    return Array.from(this.devices.values())
      .filter(device => device.userId === userId)
      .sort((a, b) => new Date(b.lastActive).getTime() - new Date(a.lastActive).getTime());
  }
  
  async updateDevice(id: number, data: Partial<Device>): Promise<Device | undefined> {
    const device = this.devices.get(id);
    if (!device) return undefined;
    
    const updatedDevice = { ...device, ...data };
    this.devices.set(id, updatedDevice);
    return updatedDevice;
  }
  
  // Anomaly operations
  async createAnomaly(anomalyData: InsertAnomaly): Promise<Anomaly> {
    const id = this.anomalyId++;
    const now = new Date();
    const anomaly: Anomaly = {
      ...anomalyData,
      id,
      status: anomalyData.status || 'new',
      location: anomalyData.location ?? null,
      sessionId: anomalyData.sessionId ?? null,
      details: anomalyData.details ?? null,
      timestamp: now
    };
    this.anomalyRecords.set(id, anomaly);
    return anomaly;
  }
  
  async getUserAnomalies(userId: number): Promise<Anomaly[]> {
    return Array.from(this.anomalyRecords.values())
      .filter(anomaly => anomaly.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async updateAnomaly(id: number, data: Partial<Anomaly>): Promise<Anomaly | undefined> {
    const anomaly = this.anomalyRecords.get(id);
    if (!anomaly) return undefined;
    
    const updatedAnomaly = { ...anomaly, ...data };
    this.anomalyRecords.set(id, updatedAnomaly);
    return updatedAnomaly;
  }
  
  // Educational resources operations
  async createEducationalResource(resourceData: InsertEducationalResource): Promise<EducationalResource> {
    const id = this.resourceId++;
    const resource: EducationalResource = {
      ...resourceData,
      id
    };
    this.educationalResources.set(id, resource);
    return resource;
  }
  
  async getAllEducationalResources(): Promise<EducationalResource[]> {
    return Array.from(this.educationalResources.values());
  }
  
  async getEducationalResource(id: number): Promise<EducationalResource | undefined> {
    return this.educationalResources.get(id);
  }
  
  // Simulation operations
  async createSimulationScenario(scenarioData: InsertSimulationScenario): Promise<SimulationScenario> {
    const id = this.scenarioId++;
    const scenario: SimulationScenario = {
      ...scenarioData,
      id
    };
    this.simulationScenarios.set(id, scenario);
    return scenario;
  }
  
  async getAllSimulationScenarios(): Promise<SimulationScenario[]> {
    return Array.from(this.simulationScenarios.values());
  }
  
  async getSimulationScenario(id: number): Promise<SimulationScenario | undefined> {
    return this.simulationScenarios.get(id);
  }
  
  // Social accounts operations
  async createSocialAccount(accountData: InsertSocialAccount): Promise<SocialAccount> {
    const id = this.socialAccountId++;
    const now = new Date();
    const account: SocialAccount = {
      ...accountData,
      id,
      username: accountData.username || null,
      profileUrl: accountData.profileUrl || null,
      accessToken: accountData.accessToken || null,
      refreshToken: accountData.refreshToken || null,
      createdAt: now
    };
    this.socialAccounts.set(id, account);
    return account;
  }
  
  async getUserSocialAccounts(userId: number): Promise<SocialAccount[]> {
    return Array.from(this.socialAccounts.values())
      .filter(account => account.userId === userId);
  }
  
  async getSocialAccountsByProviderId(providerId: string, provider: string): Promise<SocialAccount[]> {
    return Array.from(this.socialAccounts.values())
      .filter(account => account.providerId === providerId && account.provider === provider);
  }
  
  async getSocialAccount(id: number): Promise<SocialAccount | undefined> {
    return this.socialAccounts.get(id);
  }
  
  async updateSocialAccount(id: number, data: Partial<SocialAccount>): Promise<SocialAccount | undefined> {
    const account = this.socialAccounts.get(id);
    if (!account) return undefined;
    
    const updatedAccount = { ...account, ...data };
    this.socialAccounts.set(id, updatedAccount);
    return updatedAccount;
  }
  
  // Seed initial data
  private seedEducationalResources() {
    const resources: InsertEducationalResource[] = [
      {
        title: "How to Recognize Phishing",
        description: "Learn how to identify and avoid common phishing attempts targeting social media users.",
        content: `
          <h2>Recognizing Phishing Attempts</h2>
          <p>Phishing is a type of social engineering attack often used to steal user data, including login credentials and credit card numbers. It occurs when an attacker, masquerading as a trusted entity, dupes a victim into opening an email, instant message, or text message.</p>
          <h3>Common Signs of Phishing</h3>
          <ul>
            <li>Urgent call to action or unrealistic threats</li>
            <li>Suspicious or mismatched URLs</li>
            <li>Poor spelling and grammar</li>
            <li>Requests for personal information</li>
            <li>Offers that seem too good to be true</li>
          </ul>
          <h3>How to Protect Yourself</h3>
          <ul>
            <li>Never click on links in suspicious emails or messages</li>
            <li>Always verify the sender's email address</li>
            <li>Use multi-factor authentication where possible</li>
            <li>Keep your browser and security software updated</li>
            <li>When in doubt, contact the company directly through their official website</li>
          </ul>
        `,
        icon: "shield-alt",
        category: "security",
      },
      {
        title: "Password Best Practices",
        description: "Create strong, unique passwords and manage them securely with these essential tips.",
        content: `
          <h2>Password Best Practices</h2>
          <p>Strong passwords are your first line of defense against unauthorized access to your accounts and personal information.</p>
          <h3>Creating Strong Passwords</h3>
          <ul>
            <li>Use a minimum of 12 characters</li>
            <li>Include numbers, symbols, uppercase and lowercase letters</li>
            <li>Avoid using easily guessable information like birthdays or names</li>
            <li>Don't use the same password for multiple accounts</li>
            <li>Consider using a passphrase instead of a single word</li>
          </ul>
          <h3>Managing Your Passwords</h3>
          <ul>
            <li>Use a reputable password manager to store and generate passwords</li>
            <li>Change passwords periodically, especially for sensitive accounts</li>
            <li>Enable two-factor authentication whenever possible</li>
            <li>Never share your passwords with others</li>
            <li>Be cautious of saving passwords in your browser</li>
          </ul>
        `,
        icon: "lock",
        category: "security",
      },
      {
        title: "What to Do If Compromised",
        description: "Step-by-step guide on how to recover from identity theft and secure your accounts.",
        content: `
          <h2>What to Do If Your Account Is Compromised</h2>
          <p>If you suspect your account has been compromised, acting quickly can help minimize damage and protect your personal information.</p>
          <h3>Immediate Actions</h3>
          <ol>
            <li>Change your password immediately</li>
            <li>Enable two-factor authentication if available</li>
            <li>Check for any unauthorized changes to your account</li>
            <li>Review recent activities and transactions</li>
            <li>Log out of all sessions on all devices</li>
          </ol>
          <h3>Additional Steps</h3>
          <ol>
            <li>Contact the platform's support to report the compromise</li>
            <li>Alert your contacts if your account was used to send spam</li>
            <li>Check other accounts for suspicious activity</li>
            <li>Consider freezing your credit if financial information was exposed</li>
            <li>Keep monitoring your accounts for unusual activity</li>
          </ol>
          <h3>Prevention for the Future</h3>
          <ul>
            <li>Use unique passwords for each account</li>
            <li>Regularly update your security questions</li>
            <li>Be cautious about the information you share online</li>
            <li>Regularly check your privacy settings</li>
            <li>Keep all your devices and software updated</li>
          </ul>
        `,
        icon: "user-shield",
        category: "recovery",
      }
    ];
    
    resources.forEach(resource => {
      this.createEducationalResource(resource);
    });
  }
  
  private seedSimulationScenarios() {
    const scenarios: InsertSimulationScenario[] = [
      {
        title: "Suspicious Message Request",
        description: "A friend asks for your login information",
        content: "Hi there! I'm having trouble accessing our shared document. Could you send me your login details so I can check if it's a permission issue?",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "This is a common phishing tactic. Even if the message appears to be from a friend, you should never share your login credentials with anyone.",
        difficulty: "easy",
      },
      {
        title: "Unexpected Login Alert",
        description: "You receive an email about a login from a new location",
        content: "Dear user, we detected a new login to your account from Moscow, Russia. If this wasn't you, click here to secure your account immediately: [suspicious link]",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "While the alert itself might be legitimate, you should never click on links in such emails. Instead, open a new browser window and log in to your account directly to check security settings.",
        difficulty: "medium",
      },
      {
        title: "Friend's Unusual Message",
        description: "A close friend sends an unexpected message",
        content: "Hey! Check out this amazing video I found of you from last year's party: [link]",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "This is a common tactic where compromised accounts are used to spread malware. The unusual tone and unexpected link are red flags that your friend's account may have been compromised.",
        difficulty: "medium",
      }
    ];
    
    scenarios.forEach(scenario => {
      this.createSimulationScenario(scenario);
    });
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Seed initial data when created
    this.seedInitialData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  // Session operations
  async createSession(sessionData: InsertUserSession): Promise<UserSession> {
    const [session] = await db.insert(userSessions).values(sessionData).returning();
    return session;
  }
  
  async getUserSessions(userId: number): Promise<UserSession[]> {
    return await db.select()
      .from(userSessions)
      .where(eq(userSessions.userId, userId))
      .orderBy(desc(userSessions.loginTime));
  }
  
  async getSession(id: number): Promise<UserSession | undefined> {
    const [session] = await db.select().from(userSessions).where(eq(userSessions.id, id));
    return session;
  }
  
  async closeSession(userId: number): Promise<void> {
    const now = new Date();
    
    // First get all active sessions for the user
    const activeSessions = await db.select()
      .from(userSessions)
      .where(and(
        eq(userSessions.userId, userId),
        eq(userSessions.isActive, true)
      ));
    
    // Update each active session
    for (const session of activeSessions) {
      const loginTime = new Date(session.loginTime);
      const durationSeconds = Math.floor((now.getTime() - loginTime.getTime()) / 1000);
      
      await db.update(userSessions)
        .set({
          logoutTime: now,
          duration: durationSeconds,
          isActive: false
        })
        .where(eq(userSessions.id, session.id));
    }
  }
  
  // Activity operations
  async createActivity(activityData: InsertUserActivity): Promise<UserActivity> {
    const [activity] = await db.insert(userActivities).values(activityData).returning();
    return activity;
  }
  
  async getUserActivities(userId: number): Promise<UserActivity[]> {
    return await db.select()
      .from(userActivities)
      .where(eq(userActivities.userId, userId))
      .orderBy(desc(userActivities.timestamp));
  }
  
  async getRecentActivities(userId: number, limit: number): Promise<UserActivity[]> {
    return await db.select()
      .from(userActivities)
      .where(eq(userActivities.userId, userId))
      .orderBy(desc(userActivities.timestamp))
      .limit(limit);
  }
  
  // Device operations
  async createDevice(deviceData: InsertDevice): Promise<Device> {
    const [device] = await db.insert(devices).values(deviceData).returning();
    return device;
  }
  
  async getUserDevices(userId: number): Promise<Device[]> {
    return await db.select()
      .from(devices)
      .where(eq(devices.userId, userId))
      .orderBy(desc(devices.lastActive));
  }
  
  async updateDevice(id: number, data: Partial<Device>): Promise<Device | undefined> {
    const [updatedDevice] = await db.update(devices)
      .set(data)
      .where(eq(devices.id, id))
      .returning();
    return updatedDevice;
  }
  
  // Anomaly operations
  async createAnomaly(anomalyData: InsertAnomaly): Promise<Anomaly> {
    const [anomaly] = await db.insert(anomalies).values(anomalyData).returning();
    return anomaly;
  }
  
  async getUserAnomalies(userId: number): Promise<Anomaly[]> {
    return await db.select()
      .from(anomalies)
      .where(eq(anomalies.userId, userId))
      .orderBy(desc(anomalies.timestamp));
  }
  
  async updateAnomaly(id: number, data: Partial<Anomaly>): Promise<Anomaly | undefined> {
    const [updatedAnomaly] = await db.update(anomalies)
      .set(data)
      .where(eq(anomalies.id, id))
      .returning();
    return updatedAnomaly;
  }
  
  // Educational resources operations
  async createEducationalResource(resourceData: InsertEducationalResource): Promise<EducationalResource> {
    const [resource] = await db.insert(educationalResources).values(resourceData).returning();
    return resource;
  }
  
  async getAllEducationalResources(): Promise<EducationalResource[]> {
    return await db.select().from(educationalResources);
  }
  
  async getEducationalResource(id: number): Promise<EducationalResource | undefined> {
    const [resource] = await db.select()
      .from(educationalResources)
      .where(eq(educationalResources.id, id));
    return resource;
  }
  
  // Simulation operations
  async createSimulationScenario(scenarioData: InsertSimulationScenario): Promise<SimulationScenario> {
    const [scenario] = await db.insert(simulationScenarios).values(scenarioData).returning();
    return scenario;
  }
  
  async getAllSimulationScenarios(): Promise<SimulationScenario[]> {
    return await db.select().from(simulationScenarios);
  }
  
  async getSimulationScenario(id: number): Promise<SimulationScenario | undefined> {
    const [scenario] = await db.select()
      .from(simulationScenarios)
      .where(eq(simulationScenarios.id, id));
    return scenario;
  }
  
  // Social accounts operations
  async createSocialAccount(accountData: InsertSocialAccount): Promise<SocialAccount> {
    const [account] = await db.insert(socialAccounts).values(accountData).returning();
    return account;
  }
  
  async getUserSocialAccounts(userId: number): Promise<SocialAccount[]> {
    return await db.select()
      .from(socialAccounts)
      .where(eq(socialAccounts.userId, userId));
  }
  
  async getSocialAccountsByProviderId(providerId: string, provider: string): Promise<SocialAccount[]> {
    return await db.select()
      .from(socialAccounts)
      .where(and(
        eq(socialAccounts.providerId, providerId),
        eq(socialAccounts.provider, provider)
      ));
  }
  
  async getSocialAccount(id: number): Promise<SocialAccount | undefined> {
    const [account] = await db.select()
      .from(socialAccounts)
      .where(eq(socialAccounts.id, id));
    return account;
  }
  
  async updateSocialAccount(id: number, data: Partial<SocialAccount>): Promise<SocialAccount | undefined> {
    const [updatedAccount] = await db.update(socialAccounts)
      .set(data)
      .where(eq(socialAccounts.id, id))
      .returning();
    return updatedAccount;
  }
  
  // Seed initial data
  private async seedInitialData() {
    try {
      // Check if we already have educational resources
      const existingResources = await db.select().from(educationalResources);
      if (existingResources.length === 0) {
        await this.seedEducationalResources();
      }
      
      // Check if we already have simulation scenarios
      const existingScenarios = await db.select().from(simulationScenarios);
      if (existingScenarios.length === 0) {
        await this.seedSimulationScenarios();
      }
    } catch (error) {
      console.error("Error seeding initial data:", error);
      console.warn("Database seeding skipped - will continue with in-memory storage");
    }
  }
  
  private async seedEducationalResources() {
    const resources: InsertEducationalResource[] = [
      {
        title: "How to Recognize Phishing",
        description: "Learn how to identify and avoid common phishing attempts targeting social media users.",
        content: `
          <h2>Recognizing Phishing Attempts</h2>
          <p>Phishing is a type of social engineering attack often used to steal user data, including login credentials and credit card numbers. It occurs when an attacker, masquerading as a trusted entity, dupes a victim into opening an email, instant message, or text message.</p>
          <h3>Common Signs of Phishing</h3>
          <ul>
            <li>Urgent call to action or unrealistic threats</li>
            <li>Suspicious or mismatched URLs</li>
            <li>Poor spelling and grammar</li>
            <li>Requests for personal information</li>
            <li>Offers that seem too good to be true</li>
          </ul>
          <h3>How to Protect Yourself</h3>
          <ul>
            <li>Never click on links in suspicious emails or messages</li>
            <li>Always verify the sender's email address</li>
            <li>Use multi-factor authentication where possible</li>
            <li>Keep your browser and security software updated</li>
            <li>When in doubt, contact the company directly through their official website</li>
          </ul>
        `,
        icon: "shield-alt",
        category: "security",
      },
      {
        title: "Password Best Practices",
        description: "Create strong, unique passwords and manage them securely with these essential tips.",
        content: `
          <h2>Password Best Practices</h2>
          <p>Strong passwords are your first line of defense against unauthorized access to your accounts and personal information.</p>
          <h3>Creating Strong Passwords</h3>
          <ul>
            <li>Use a minimum of 12 characters</li>
            <li>Include numbers, symbols, uppercase and lowercase letters</li>
            <li>Avoid using easily guessable information like birthdays or names</li>
            <li>Don't use the same password for multiple accounts</li>
            <li>Consider using a passphrase instead of a single word</li>
          </ul>
          <h3>Managing Your Passwords</h3>
          <ul>
            <li>Use a reputable password manager to store and generate passwords</li>
            <li>Change passwords periodically, especially for sensitive accounts</li>
            <li>Enable two-factor authentication whenever possible</li>
            <li>Never share your passwords with others</li>
            <li>Be cautious of saving passwords in your browser</li>
          </ul>
        `,
        icon: "lock",
        category: "security",
      },
      {
        title: "What to Do If Compromised",
        description: "Step-by-step guide on how to recover from identity theft and secure your accounts.",
        content: `
          <h2>What to Do If Your Account Is Compromised</h2>
          <p>If you suspect your account has been compromised, acting quickly can help minimize damage and protect your personal information.</p>
          <h3>Immediate Actions</h3>
          <ol>
            <li>Change your password immediately</li>
            <li>Enable two-factor authentication if available</li>
            <li>Check for any unauthorized changes to your account</li>
            <li>Review recent activities and transactions</li>
            <li>Log out of all sessions on all devices</li>
          </ol>
          <h3>Additional Steps</h3>
          <ol>
            <li>Contact the platform's support to report the compromise</li>
            <li>Alert your contacts if your account was used to send spam</li>
            <li>Check other accounts for suspicious activity</li>
            <li>Consider freezing your credit if financial information was exposed</li>
            <li>Keep monitoring your accounts for unusual activity</li>
          </ol>
          <h3>Prevention for the Future</h3>
          <ul>
            <li>Use unique passwords for each account</li>
            <li>Regularly update your security questions</li>
            <li>Be cautious about the information you share online</li>
            <li>Regularly check your privacy settings</li>
            <li>Keep all your devices and software updated</li>
          </ul>
        `,
        icon: "user-shield",
        category: "recovery",
      }
    ];
    
    // Insert all resources
    for (const resource of resources) {
      await this.createEducationalResource(resource);
    }
  }
  
  private async seedSimulationScenarios() {
    const scenarios: InsertSimulationScenario[] = [
      {
        title: "Suspicious Message Request",
        description: "A friend asks for your login information",
        content: "Hi there! I'm having trouble accessing our shared document. Could you send me your login details so I can check if it's a permission issue?",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "This is a common phishing tactic. Even if the message appears to be from a friend, you should never share your login credentials with anyone.",
        difficulty: "easy",
      },
      {
        title: "Unexpected Login Alert",
        description: "You receive an email about a login from a new location",
        content: "Dear user, we detected a new login to your account from Moscow, Russia. If this wasn't you, click here to secure your account immediately: [suspicious link]",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "While the alert itself might be legitimate, you should never click on links in such emails. Instead, open a new browser window and log in to your account directly to check security settings.",
        difficulty: "medium",
      },
      {
        title: "Friend's Unusual Message",
        description: "A close friend sends an unexpected message",
        content: "Hey! Check out this amazing video I found of you from last year's party: [link]",
        correctAnswer: true, // Yes, it's suspicious
        explanation: "Be wary of messages with unexpected links, even from friends. Their account might have been compromised. Always verify with them through another communication channel before clicking.",
        difficulty: "medium",
      }
    ];
    
    // Insert all scenarios
    for (const scenario of scenarios) {
      await this.createSimulationScenario(scenario);
    }
  }
}

// Use database storage
export const storage = new DatabaseStorage();
