import { Anomaly, InsertAnomaly, UserSession, UserActivity } from "@shared/schema";

// Basic anomaly detection system
export class AnomalyDetector {
  // Detect unusual login time anomaly
  detectUnusualLoginTime(session: UserSession, sessions: UserSession[]): Anomaly | null {
    if (sessions.length < 3) return null; // Not enough data for baseline
    
    // Get user's typical login times (hours)
    const loginHours = sessions
      .filter(s => s.id !== session.id)
      .map(s => new Date(s.loginTime).getHours());
    
    // Calculate average login hour and standard deviation
    const sum = loginHours.reduce((acc, hour) => acc + hour, 0);
    const avg = sum / loginHours.length;
    
    const squaredDiffs = loginHours.map(hour => Math.pow(hour - avg, 2));
    const variance = squaredDiffs.reduce((acc, diff) => acc + diff, 0) / loginHours.length;
    const stdDev = Math.sqrt(variance);
    
    const currentHour = new Date(session.loginTime).getHours();
    const deviation = Math.abs(currentHour - avg);
    
    // If login time is more than 2.5 standard deviations from mean, flag as anomaly
    if (deviation > (2.5 * stdDev) && stdDev > 0) {
      return {
        id: 0, // Will be assigned by storage
        userId: session.userId,
        sessionId: session.id,
        anomalyType: "unusual_login_time",
        details: `Login at ${currentHour}:00 is unusual compared to typical pattern (avg: ${avg.toFixed(1)}:00)`,
        riskLevel: deviation > (3.5 * stdDev) ? "high" : "medium",
        status: "unresolved",
        timestamp: new Date(),
        location: session.location || "Unknown",
      };
    }
    
    return null;
  }
  
  // Detect logins from new location
  detectNewLocation(session: UserSession, sessions: UserSession[]): Anomaly | null {
    const previousLocations = new Set(
      sessions
        .filter(s => s.id !== session.id)
        .map(s => s.location)
        .filter(Boolean)
    );
    
    // If we have previous sessions and this location is new
    if (previousLocations.size > 0 && session.location && !previousLocations.has(session.location)) {
      return {
        id: 0, // Will be assigned by storage
        userId: session.userId,
        sessionId: session.id,
        anomalyType: "new_location",
        details: `First login detected from ${session.location}`,
        riskLevel: "medium",
        status: "unresolved",
        timestamp: new Date(),
        location: session.location,
      };
    }
    
    return null;
  }
  
  // Detect new device
  detectNewDevice(session: UserSession, sessions: UserSession[]): Anomaly | null {
    const previousDevices = new Set(
      sessions
        .filter(s => s.id !== session.id)
        .map(s => s.device)
        .filter(Boolean)
    );
    
    // If we have previous sessions and this device is new
    if (previousDevices.size > 0 && session.device && !previousDevices.has(session.device)) {
      return {
        id: 0, // Will be assigned by storage
        userId: session.userId,
        sessionId: session.id,
        anomalyType: "new_device",
        details: `First login detected from ${session.device}`,
        riskLevel: "low",
        status: "unresolved",
        timestamp: new Date(),
        location: session.location || "Unknown",
      };
    }
    
    return null;
  }
  
  // Detect rapid activity (too many actions in short time)
  detectRapidActivity(activities: UserActivity[]): Anomaly | null {
    if (activities.length < 10) return null; // Need sufficient activity for detection
    
    // Check if there are more than 30 activities within a 5-minute window
    const fiveMinutes = 5 * 60 * 1000; // 5 minutes in milliseconds
    
    // Sort activities by timestamp
    const sortedActivities = [...activities].sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Use sliding window to detect rapid activity
    for (let i = 0; i < sortedActivities.length - 10; i++) {
      const startTime = new Date(sortedActivities[i].timestamp).getTime();
      const endTime = new Date(sortedActivities[i + 9].timestamp).getTime();
      
      // If 10 actions happened within 30 seconds
      if (endTime - startTime < 30000) {
        return {
          id: 0, // Will be assigned by storage
          userId: activities[0].userId,
          sessionId: activities[0].sessionId,
          anomalyType: "rapid_activity",
          details: `Detected 10 actions within ${((endTime - startTime) / 1000).toFixed(1)} seconds`,
          riskLevel: "medium",
          status: "unresolved",
          timestamp: new Date(),
          location: "Unknown",
        };
      }
    }
    
    return null;
  }
  
  // Process a new session to detect anomalies
  detectSessionAnomalies(
    newSession: UserSession, 
    previousSessions: UserSession[]
  ): Anomaly[] {
    const anomalies: Anomaly[] = [];
    
    const unusualTimeAnomaly = this.detectUnusualLoginTime(newSession, previousSessions);
    if (unusualTimeAnomaly) anomalies.push(unusualTimeAnomaly);
    
    const newLocationAnomaly = this.detectNewLocation(newSession, previousSessions);
    if (newLocationAnomaly) anomalies.push(newLocationAnomaly);
    
    const newDeviceAnomaly = this.detectNewDevice(newSession, previousSessions);
    if (newDeviceAnomaly) anomalies.push(newDeviceAnomaly);
    
    return anomalies;
  }
  
  // Process activity batch to detect anomalies
  detectActivityAnomalies(
    activities: UserActivity[]
  ): Anomaly[] {
    const anomalies: Anomaly[] = [];
    
    const rapidActivityAnomaly = this.detectRapidActivity(activities);
    if (rapidActivityAnomaly) anomalies.push(rapidActivityAnomaly);
    
    return anomalies;
  }
}

export const anomalyDetector = new AnomalyDetector();
