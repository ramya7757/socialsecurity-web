import { useState } from "react";
import { SimulationScenario } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface ScenarioCardProps {
  scenario: SimulationScenario;
}

export default function ScenarioCard({ scenario }: ScenarioCardProps) {
  const [showAnswer, setShowAnswer] = useState(false);
  const [userAnswer, setUserAnswer] = useState<boolean | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  
  const handleAnswer = (answer: boolean) => {
    setUserAnswer(answer);
    setShowAnswer(true);
  };
  
  const handleClose = () => {
    setShowExplanation(false);
    setShowAnswer(false);
    setUserAnswer(null);
  };
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-success text-success-foreground";
      case "medium":
        return "bg-primary text-primary-foreground";
      case "hard":
        return "bg-destructive text-destructive-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };
  
  return (
    <>
      <Card className="h-full card-hover">
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <h3 className="font-medium">{scenario.title}</h3>
            <Badge className={`capitalize ${getDifficultyColor(scenario.difficulty)}`}>
              {scenario.difficulty}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-4">{scenario.description}</p>
          
          <div className="p-3 bg-muted rounded border mb-4">
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2 shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                  <path d="M18 20a6 6 0 0 0-12 0"></path>
                  <circle cx="12" cy="10" r="4"></circle>
                  <circle cx="12" cy="12" r="10"></circle>
                </svg>
              </div>
              <div>
                <div className="font-medium">User Message</div>
                <div className="text-xs text-muted-foreground">2 hours ago</div>
                <div className="text-sm mt-1">{scenario.content}</div>
              </div>
            </div>
          </div>
          
          <div className="text-sm mb-3">Is this a potential identity theft attempt?</div>
          
          {!showAnswer ? (
            <div className="grid grid-cols-2 gap-2">
              <Button 
                variant="destructive" 
                className="w-full"
                onClick={() => handleAnswer(true)}
              >
                Yes, it's suspicious
              </Button>
              <Button 
                variant="secondary" 
                className="w-full"
                onClick={() => handleAnswer(false)}
              >
                No, it's legitimate
              </Button>
            </div>
          ) : (
            <div className="text-center">
              <div className={`font-medium text-lg mb-2 ${
                userAnswer === scenario.correctAnswer 
                  ? "text-success" 
                  : "text-destructive"
              }`}>
                {userAnswer === scenario.correctAnswer 
                  ? "Correct!" 
                  : "Incorrect!"}
              </div>
              <Button
                variant="outline"
                onClick={() => setShowExplanation(true)}
                className="mr-2"
              >
                View Explanation
              </Button>
              <Button
                variant="default"
                onClick={handleClose}
              >
                Try Another
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showExplanation} onOpenChange={setShowExplanation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Explanation</AlertDialogTitle>
            <AlertDialogDescription>
              <p className="my-2">{scenario.explanation}</p>
              <p className="my-2 font-medium">
                The correct answer is: {scenario.correctAnswer ? "Yes, it's suspicious" : "No, it's legitimate"}
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button onClick={() => setShowExplanation(false)}>Close</Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
