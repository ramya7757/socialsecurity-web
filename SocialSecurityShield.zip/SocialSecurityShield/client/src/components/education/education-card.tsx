import { EducationalResource } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldAlert, Lock, UserCheck } from "lucide-react";

interface EducationCardProps {
  resource: EducationalResource;
}

function getResourceIcon(icon: string) {
  switch (icon) {
    case "shield-alt":
      return <ShieldAlert className="text-primary text-3xl" />;
    case "lock":
      return <Lock className="text-primary text-3xl" />;
    case "user-shield":
      return <UserCheck className="text-primary text-3xl" />;
    default:
      return <ShieldAlert className="text-primary text-3xl" />;
  }
}

export default function EducationCard({ resource }: EducationCardProps) {
  return (
    <Card className="h-full card-hover">
      <CardContent className="p-4">
        <div className="mb-3">{getResourceIcon(resource.icon)}</div>
        <h3 className="font-medium mb-2">{resource.title}</h3>
        <p className="text-sm text-muted-foreground mb-3">{resource.description}</p>
        <a href={`/education/${resource.id}`} className="text-sm text-primary hover:underline">
          Read More →
        </a>
      </CardContent>
    </Card>
  );
}
