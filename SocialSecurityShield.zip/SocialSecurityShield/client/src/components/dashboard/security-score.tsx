import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { InfoIcon, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useEffect, useRef } from "react";
import { Chart, DoughnutController, ArcElement, Tooltip as ChartTooltip } from "chart.js";

Chart.register(DoughnutController, ArcElement, ChartTooltip);

export default function SecurityScore() {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  const { data: securityScore, isLoading } = useQuery<{ score: number }>({
    queryKey: ["/api/user/security-score"],
  });
  
  useEffect(() => {
    if (!chartRef.current || !securityScore) return;
    
    // Destroy existing chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    const ctx = chartRef.current.getContext("2d");
    if (!ctx) return;
    
    chartInstance.current = new Chart(ctx, {
      type: "doughnut",
      data: {
        datasets: [{
          data: [securityScore.score, 100 - securityScore.score],
          backgroundColor: ["hsl(var(--primary))", "hsl(var(--muted))"],
          borderWidth: 0
        }]
      },
      options: {
        cutout: "80%",
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            enabled: false
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [securityScore]);

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-medium">Security Score</h2>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-4 w-4 text-muted-foreground cursor-pointer" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">Your overall security rating based on behavior patterns and security settings</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        
        <div className="flex flex-col items-center">
          {isLoading ? (
            <div className="w-28 h-28 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="relative w-28 h-28 mb-4">
              <canvas ref={chartRef}></canvas>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-3xl font-medium text-primary">
                  {securityScore?.score || 0}
                </span>
                <span className="text-xs text-muted-foreground">out of 100</span>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-3 gap-2 w-full text-center text-sm">
            <div>
              <div className="font-medium">Low</div>
              <div className="text-xs text-muted-foreground">0-50</div>
            </div>
            <div>
              <div className="font-medium">Medium</div>
              <div className="text-xs text-muted-foreground">51-80</div>
            </div>
            <div>
              <div className={`font-medium ${securityScore?.score && securityScore.score > 80 ? "text-primary" : ""}`}>High</div>
              <div className="text-xs text-muted-foreground">81-100</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
