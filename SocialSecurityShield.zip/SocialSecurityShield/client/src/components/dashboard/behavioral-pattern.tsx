import { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { UserSession } from "@shared/schema";
import { Chart, LineController, LineElement, PointElement, LinearScale, CategoryScale, Legend, Tooltip } from "chart.js";

Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Legend, Tooltip);

type PatternType = "login_times" | "session_duration" | "activity_types";

export default function BehavioralPattern() {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const [patternType, setPatternType] = useState<PatternType>("login_times");
  
  const { data: sessions, isLoading } = useQuery<UserSession[]>({
    queryKey: ["/api/user/sessions"],
  });
  
  useEffect(() => {
    if (!chartRef.current || !sessions || sessions.length === 0) return;
    
    // Destroy existing chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    const ctx = chartRef.current.getContext("2d");
    if (!ctx) return;
    
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    
    // Mock data for demonstration (in a real app, this would come from the API)
    const userData = [8, 10, 6, 9, 12, 8, 7];
    const baselineData = [9, 8, 7, 9, 10, 11, 8];
    
    chartInstance.current = new Chart(ctx, {
      type: "line",
      data: {
        labels: days,
        datasets: [
          {
            label: "Your Activity",
            data: userData,
            borderColor: "hsl(var(--primary))",
            backgroundColor: "hsl(var(--primary) / 0.1)",
            fill: true,
            tension: 0.4
          },
          {
            label: "Normal Pattern",
            data: baselineData,
            borderColor: "hsl(var(--muted-foreground))",
            borderDash: [5, 5],
            backgroundColor: "transparent",
            fill: false,
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: patternType === "login_times" 
                ? "Login Hour (24h)" 
                : patternType === "session_duration" 
                  ? "Duration (minutes)"
                  : "Activity Count"
            }
          }
        }
      }
    });
    
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [sessions, patternType]);
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-medium">Behavioral Pattern</h2>
          <Select 
            defaultValue={patternType} 
            onValueChange={(value) => setPatternType(value as PatternType)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select pattern" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="login_times">Login Times</SelectItem>
              <SelectItem value="session_duration">Session Duration</SelectItem>
              <SelectItem value="activity_types">Activity Types</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="h-64">
            <canvas ref={chartRef}></canvas>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
