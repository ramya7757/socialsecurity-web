import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Anomaly } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function AnomalyDetection() {
  const { data: anomalies, isLoading } = useQuery<Anomaly[]>({
    queryKey: ["/api/user/anomalies"],
  });
  
  const unresolvedCount = anomalies?.filter(a => a.status === "unresolved").length || 0;
  
  const handleResolve = async (id: number) => {
    await apiRequest("PATCH", `/api/user/anomalies/${id}`, { status: "resolved" });
    queryClient.invalidateQueries({ queryKey: ["/api/user/anomalies"] });
  };
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-medium">Anomaly Detection</h2>
          {!isLoading && anomalies && (
            <Badge variant="outline" className="px-3 py-1 rounded-full text-xs">
              {unresolvedCount} anomalies detected
            </Badge>
          )}
        </div>
        
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : anomalies && anomalies.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">Type</TableHead>
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Location</TableHead>
                  <TableHead className="whitespace-nowrap">Risk Level</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {anomalies.map((anomaly) => (
                  <TableRow key={anomaly.id}>
                    <TableCell className="font-medium">
                      {anomaly.anomalyType.replace(/_/g, ' ')}
                    </TableCell>
                    <TableCell>
                      {formatDistanceToNow(new Date(anomaly.timestamp), { addSuffix: true })}
                    </TableCell>
                    <TableCell>{anomaly.location}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          anomaly.riskLevel === "high" 
                            ? "destructive" 
                            : anomaly.riskLevel === "medium" 
                              ? "default" 
                              : "outline"
                        }
                        className="capitalize"
                      >
                        {anomaly.riskLevel}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={
                        anomaly.status === "unresolved" 
                          ? "text-destructive font-medium" 
                          : "text-success font-medium"
                      }>
                        {anomaly.status}
                      </span>
                    </TableCell>
                    <TableCell>
                      {anomaly.status === "unresolved" && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleResolve(anomaly.id)}
                        >
                          Resolve
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="h-32 flex items-center justify-center text-muted-foreground">
            No anomalies detected
          </div>
        )}
      </CardContent>
    </Card>
  );
}
