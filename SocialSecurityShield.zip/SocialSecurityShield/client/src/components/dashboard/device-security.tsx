import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Laptop, Smartphone, Tablet } from "lucide-react";
import { Device } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

function getDeviceIcon(deviceType: string) {
  switch (deviceType.toLowerCase()) {
    case "mobile":
    case "phone":
    case "iphone":
      return <Smartphone className="h-5 w-5" />;
    case "tablet":
    case "ipad":
      return <Tablet className="h-5 w-5" />;
    default:
      return <Laptop className="h-5 w-5" />;
  }
}

export default function DeviceSecurity() {
  const { data: devices, isLoading } = useQuery<Device[]>({
    queryKey: ["/api/user/devices"],
  });
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-medium">Device Security</h2>
          <Button variant="ghost" size="sm" className="text-primary">
            Manage
          </Button>
        </div>
        
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : devices && devices.length > 0 ? (
          <div className="space-y-4">
            {devices.map((device) => (
              <div key={device.id} className="flex items-center p-3 border rounded-lg">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center mr-3">
                  {getDeviceIcon(device.deviceType)}
                </div>
                <div className="flex-grow">
                  <div className="font-medium">{device.deviceName}</div>
                  <div className="text-xs text-muted-foreground">
                    Last active: {formatDistanceToNow(new Date(device.lastActive), { addSuffix: true })}
                  </div>
                </div>
                <Badge 
                  variant={device.isPrimary ? "default" : "outline"}
                  className={device.isPrimary ? "bg-success text-success-foreground" : ""}
                >
                  {device.isPrimary ? "Primary" : "Trusted"}
                </Badge>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-32 flex items-center justify-center text-muted-foreground">
            No devices registered
          </div>
        )}
      </CardContent>
    </Card>
  );
}
