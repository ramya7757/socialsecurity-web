import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, ArrowUpIcon, ArrowDownIcon, CircleIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Device } from "@shared/schema";

type BehaviorSummaryData = {
  loginCount: number;
  deviceCount: number;
  avgSessionDuration: number;
  primaryDevice: Device | null;
};

export default function BehaviorSummary() {
  const [timeRange, setTimeRange] = useState("7");
  
  const { data, isLoading, refetch } = useQuery<BehaviorSummaryData>({
    queryKey: ["/api/user/behavior", timeRange],
  });
  
  const handleRefresh = () => {
    refetch();
  };
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-medium">Behavior Summary</h2>
          <div className="flex space-x-2">
            <Select defaultValue={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="Select range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-xs flex items-center"
              onClick={handleRefresh}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M21 2v6h-6"></path>
                <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
                <path d="M3 22v-6h6"></path>
                <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
              </svg>
              Refresh
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="h-32 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Login Activity */}
            <div className="p-4 rounded-lg border">
              <div className="flex items-center space-x-2 mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                  <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                  <polyline points="10 17 15 12 10 7"></polyline>
                  <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
                <span className="font-medium">Login Activity</span>
              </div>
              <div className="text-3xl font-medium mb-1">{data?.loginCount || 0}</div>
              <div className="text-sm text-muted-foreground mb-2">Logins this period</div>
              <div className="flex items-center text-sm">
                <ArrowUpIcon className="h-4 w-4 text-success mr-1" />
                <span className="text-success font-medium">12%</span>
                <span className="text-muted-foreground ml-1">vs previous</span>
              </div>
            </div>

            {/* Device Usage */}
            <div className="p-4 rounded-lg border">
              <div className="flex items-center space-x-2 mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                  <rect width="20" height="14" x="2" y="3" rx="2" ry="2"></rect>
                  <line x1="8" x2="16" y1="21" y2="21"></line>
                  <line x1="12" x2="12" y1="17" y2="21"></line>
                </svg>
                <span className="font-medium">Devices Used</span>
              </div>
              <div className="text-3xl font-medium mb-1">{data?.deviceCount || 0}</div>
              <div className="text-sm text-muted-foreground mb-2">Active devices</div>
              <div className="flex items-center text-sm">
                <CircleIcon className="h-2 w-2 text-success mr-1" />
                <span className="text-foreground">
                  Primary: {data?.primaryDevice?.deviceName || "None"}
                </span>
              </div>
            </div>

            {/* Session Time */}
            <div className="p-4 rounded-lg border">
              <div className="flex items-center space-x-2 mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
                <span className="font-medium">Session Time</span>
              </div>
              <div className="text-3xl font-medium mb-1">
                {data?.avgSessionDuration.toFixed(1) || "0.0"}
              </div>
              <div className="text-sm text-muted-foreground mb-2">Avg. hours per day</div>
              <div className="flex items-center text-sm">
                <ArrowDownIcon className="h-4 w-4 text-destructive mr-1" />
                <span className="text-destructive font-medium">8%</span>
                <span className="text-muted-foreground ml-1">vs previous</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
