import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Bell, ChevronDown, Menu, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useQuery } from "@tanstack/react-query";
import { Anomaly } from "@shared/schema";

export default function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Fetch user anomalies for notification bell
  const { data: anomalies } = useQuery<Anomaly[]>({
    queryKey: ["/api/user/anomalies"],
    enabled: !!user,
  });
  
  const unresolvedAnomalies = anomalies?.filter(a => a.status === "unresolved") || [];
  
  const navLinks = [
    { label: "Dashboard", href: "/" },
    { label: "Behavior Analytics", href: "/behavior-analytics" },
    { label: "Threat Detection", href: "/threat-detection" },
    { label: "Learn", href: "/education" },
    { label: "Simulation", href: "/simulation" },
  ];
  
  // Add admin link if user is admin
  if (user?.role === "admin") {
    navLinks.push({ label: "Admin Panel", href: "/admin" });
  }
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <nav className="bg-primary text-primary-foreground shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Link href="/">
            <a className="flex items-center space-x-2">
              <Shield className="h-6 w-6" />
              <span className="text-xl font-medium">OSN Shield</span>
            </a>
          </Link>
        </div>
        
        {/* Navigation Links - Desktop */}
        <div className="hidden md:flex space-x-6">
          {navLinks.map((link) => (
            <Link href={link.href} key={link.href}>
              <a className={`py-2 hover:text-accent transition-colors ${
                location === link.href ? "font-medium" : ""
              }`}>
                {link.label}
              </a>
            </Link>
          ))}
        </div>
        
        {/* User Menu */}
        {user && (
          <div className="flex items-center space-x-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  {unresolvedAnomalies.length > 0 && (
                    <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center">
                      {unresolvedAnomalies.length}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="px-2 py-1.5 text-sm font-medium">Notifications</div>
                <DropdownMenuSeparator />
                {unresolvedAnomalies.length > 0 ? (
                  <>
                    {unresolvedAnomalies.slice(0, 3).map((anomaly) => (
                      <DropdownMenuItem key={anomaly.id} className="flex items-start gap-2 p-3">
                        <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                        <div>
                          <div className="font-medium text-sm">{anomaly.anomalyType.replace('_', ' ')}</div>
                          <div className="text-xs text-muted-foreground">{anomaly.details}</div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                    <Link href="/threat-detection">
                      <a className="w-full">
                        <DropdownMenuItem className="justify-center">
                          View all alerts
                        </DropdownMenuItem>
                      </a>
                    </Link>
                  </>
                ) : (
                  <div className="px-2 py-4 text-center text-sm text-muted-foreground">
                    No new notifications
                  </div>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden md:block">{user.username}</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="font-medium">Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Mobile menu button */}
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden" 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden px-2 pt-2 pb-3 space-y-1 border-t border-primary-foreground/20">
          {navLinks.map((link) => (
            <Link href={link.href} key={link.href}>
              <a 
                className={`block px-3 py-2 rounded-md text-base ${
                  location === link.href 
                    ? "font-medium bg-primary-foreground/10" 
                    : "hover:bg-primary-foreground/10"
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </a>
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
