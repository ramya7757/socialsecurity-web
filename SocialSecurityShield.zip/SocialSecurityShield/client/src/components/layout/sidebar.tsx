import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  LineChart, 
  AlertTriangle, 
  Book, 
  PlayCircle,
  Settings,
  Shield,
  Users,
  ChevronRight
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type SidebarItemProps = {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
};

function SidebarItem({ href, icon, label, active, onClick }: SidebarItemProps) {
  return (
    <Link href={href}>
      <a 
        className={cn(
          "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
          active
            ? "bg-primary text-primary-foreground"
            : "hover:bg-primary/10 text-foreground"
        )}
        onClick={onClick}
      >
        {icon}
        <span>{label}</span>
      </a>
    </Link>
  );
}

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [expanded, setExpanded] = useState(true);
  
  const isAdmin = user?.role === "admin";

  const sidebarItems = [
    {
      href: "/",
      icon: <LayoutDashboard size={18} />,
      label: "Dashboard",
    },
    {
      href: "/behavior-analytics",
      icon: <LineChart size={18} />,
      label: "Behavior Analytics",
    },
    {
      href: "/threat-detection",
      icon: <AlertTriangle size={18} />,
      label: "Threat Detection",
    },
    {
      href: "/education",
      icon: <Book size={18} />,
      label: "Learn",
    },
    {
      href: "/simulation",
      icon: <PlayCircle size={18} />,
      label: "Simulation",
    },
  ];
  
  const adminItems = [
    {
      href: "/admin",
      icon: <Users size={18} />,
      label: "User Management",
    },
    {
      href: "/admin/settings",
      icon: <Settings size={18} />,
      label: "System Settings",
    },
  ];

  return (
    <div className="flex flex-col h-full border-r bg-card">
      <div className="p-4">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold">OSN Shield</span>
        </div>
        
        <nav className="space-y-1.5">
          {sidebarItems.map((item) => (
            <SidebarItem
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              active={location === item.href}
            />
          ))}
          
          {isAdmin && (
            <Collapsible>
              <CollapsibleTrigger className="flex items-center justify-between w-full rounded-md px-3 py-2 text-sm hover:bg-primary/10 text-foreground">
                <div className="flex items-center gap-3">
                  <Users size={18} />
                  <span>Admin</span>
                </div>
                <ChevronRight size={16} className="transform transition-transform ui-open:rotate-90" />
              </CollapsibleTrigger>
              <CollapsibleContent className="pl-4 mt-1 space-y-1">
                {adminItems.map((item) => (
                  <SidebarItem
                    key={item.href}
                    href={item.href}
                    icon={item.icon}
                    label={item.label}
                    active={location === item.href}
                  />
                ))}
              </CollapsibleContent>
            </Collapsible>
          )}
        </nav>
      </div>
    </div>
  );
}
