import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { insertUserSchema, loginUserSchema } from "@shared/schema";
import { Shield, KeyRound, User, LockKeyhole, UserPlus, Mail } from "lucide-react";
import { FaFacebook, FaInstagram, FaSnapchat, FaGoogle } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";

// Extended schemas with additional validation
const loginSchema = loginUserSchema.extend({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
});

const registerSchema = insertUserSchema.extend({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
  confirmPassword: z.string(),
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters.",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const { 
    user, 
    loginMutation, 
    registerMutation,
    facebookLoginMutation,
    instagramLoginMutation,
    snapchatLoginMutation,
    gmailLoginMutation 
  } = useAuth();
  const [location, navigate] = useLocation();

  // Redirect if user is already logged in
  if (user) {
    navigate("/");
    return null;
  }

  // Login form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
    },
  });

  function onLoginSubmit(values: z.infer<typeof loginSchema>) {
    loginMutation.mutate(values);
  }

  function onRegisterSubmit(values: z.infer<typeof registerSchema>) {
    // Remove confirmPassword field before submitting
    const { confirmPassword, ...registrationData } = values;
    registerMutation.mutate(registrationData);
  }

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex flex-1">
        <div className="w-full lg:w-1/2 flex items-center justify-center p-6 bg-white">
          <div className="w-full max-w-md">
            <div className="flex items-center mb-8">
              <Shield className="h-8 w-8 text-primary mr-2" />
              <h1 className="text-2xl font-bold">OSN Shield</h1>
            </div>

            <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <h2 className="text-2xl font-medium mb-6">Welcome Back</h2>
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <User className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input placeholder="Enter your username" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <KeyRound className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input type="password" placeholder="••••••••" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Logging in...
                        </>
                      ) : (
                        "Login"
                      )}
                    </Button>
                  </form>
                </Form>
                <div className="mt-6">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-muted-foreground">
                        or continue with
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        // Use the values from the regular login form for simplicity
                        const values = loginForm.getValues();
                        facebookLoginMutation.mutate({
                          username: values.username,
                          password: values.password,
                        });
                      }}
                      disabled={loginMutation.isPending}
                    >
                      <FaFacebook className="mr-2 h-5 w-5 text-blue-600" />
                      Facebook
                    </Button>
                    
                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        // Use the values from the regular login form for simplicity
                        const values = loginForm.getValues();
                        instagramLoginMutation.mutate({
                          username: values.username,
                          password: values.password,
                        });
                      }}
                      disabled={loginMutation.isPending}
                    >
                      <FaInstagram className="mr-2 h-5 w-5 text-pink-600" />
                      Instagram
                    </Button>
                    
                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        // Use the values from the regular login form for simplicity
                        const values = loginForm.getValues();
                        snapchatLoginMutation.mutate({
                          username: values.username,
                          password: values.password,
                        });
                      }}
                      disabled={loginMutation.isPending}
                    >
                      <FaSnapchat className="mr-2 h-5 w-5 text-yellow-400" />
                      Snapchat
                    </Button>
                    
                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        // Use the values from the regular login form for simplicity
                        const values = loginForm.getValues();
                        gmailLoginMutation.mutate({
                          username: values.username,
                          password: values.password,
                        });
                      }}
                      disabled={loginMutation.isPending}
                    >
                      <FaGoogle className="mr-2 h-5 w-5 text-red-500" />
                      Gmail
                    </Button>
                  </div>
                </div>
                
                <div className="mt-4 text-sm text-center">
                  <span className="text-muted-foreground">Don't have an account? </span>
                  <button 
                    className="text-primary hover:underline" 
                    onClick={() => setActiveTab("register")}
                  >
                    Register now
                  </button>
                </div>
              </TabsContent>

              <TabsContent value="register">
                <h2 className="text-2xl font-medium mb-6">Create an Account</h2>
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <User className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input placeholder="John Smith" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Mail className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input placeholder="johndoe" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <LockKeyhole className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input type="password" placeholder="••••••••" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <LockKeyhole className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                              <Input type="password" placeholder="••••••••" className="pl-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating Account...
                        </>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </form>
                </Form>
                <div className="mt-4 text-sm text-center">
                  <span className="text-muted-foreground">Already have an account? </span>
                  <button 
                    className="text-primary hover:underline" 
                    onClick={() => setActiveTab("login")}
                  >
                    Login
                  </button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="hidden lg:block lg:w-1/2 bg-primary relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/90"></div>
          <div className="relative z-10 flex flex-col justify-center h-full px-12 text-white">
            <h2 className="text-4xl font-bold mb-4">Protect Your Online Identity</h2>
            <p className="text-xl mb-8">
              OSN Shield uses advanced behavioral modeling to detect and prevent identity theft in online social networks.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/10 p-4 rounded-lg backdrop-blur">
                <div className="rounded-full w-10 h-10 bg-white/20 flex items-center justify-center mb-3">
                  <Shield className="h-5 w-5" />
                </div>
                <h3 className="font-medium text-lg mb-2">Behavioral Analysis</h3>
                <p className="text-white/80">
                  Advanced algorithms detect unusual patterns in your online behavior to identify potential threats.
                </p>
              </div>
              <div className="bg-white/10 p-4 rounded-lg backdrop-blur">
                <div className="rounded-full w-10 h-10 bg-white/20 flex items-center justify-center mb-3">
                  <UserPlus className="h-5 w-5" />
                </div>
                <h3 className="font-medium text-lg mb-2">Threat Detection</h3>
                <p className="text-white/80">
                  Real-time monitoring and alerts when suspicious activities are detected on your accounts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
