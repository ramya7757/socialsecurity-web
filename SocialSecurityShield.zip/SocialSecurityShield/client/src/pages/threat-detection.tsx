import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Anomaly } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  AlertTriangle, 
  ShieldAlert, 
  Shield, 
  Clock, 
  MapPin, 
  Smartphone,
  Fingerprint,
  ArrowUpRight,
  ArrowDownRight,
  Loader2
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ThreatDetection() {
  const [selectedAnomaly, setSelectedAnomaly] = useState<Anomaly | null>(null);
  const [showAnomalyDetails, setShowAnomalyDetails] = useState(false);
  
  const { data: anomalies, isLoading } = useQuery<Anomaly[]>({
    queryKey: ["/api/user/anomalies"],
  });
  
  const highRiskCount = anomalies?.filter(a => a.riskLevel === "high")?.length || 0;
  const mediumRiskCount = anomalies?.filter(a => a.riskLevel === "medium")?.length || 0;
  const lowRiskCount = anomalies?.filter(a => a.riskLevel === "low")?.length || 0;
  const unresolvedCount = anomalies?.filter(a => a.status === "unresolved")?.length || 0;
  
  const handleResolveAnomaly = async (id: number) => {
    await apiRequest("PATCH", `/api/user/anomalies/${id}`, { status: "resolved" });
    queryClient.invalidateQueries({ queryKey: ["/api/user/anomalies"] });
    setShowAnomalyDetails(false);
  };
  
  const showAnomalyDialog = (anomaly: Anomaly) => {
    setSelectedAnomaly(anomaly);
    setShowAnomalyDetails(true);
  };
  
  const getRiskBadge = (level: string) => {
    switch (level) {
      case "high":
        return <Badge variant="destructive" className="ml-2">High</Badge>;
      case "medium":
        return <Badge className="ml-2 bg-amber-500">Medium</Badge>;
      case "low":
        return <Badge variant="outline" className="ml-2">Low</Badge>;
      default:
        return null;
    }
  };
  
  const getAnomalyIcon = (type: string) => {
    switch (type) {
      case "unusual_login_time":
        return <Clock className="h-8 w-8 text-amber-500" />;
      case "new_location":
        return <MapPin className="h-8 w-8 text-amber-500" />;
      case "new_device":
        return <Smartphone className="h-8 w-8 text-blue-500" />;
      case "rapid_activity":
        return <Fingerprint className="h-8 w-8 text-amber-500" />;
      default:
        return <AlertTriangle className="h-8 w-8 text-red-500" />;
    }
  };
  
  function getThreatStatusColor(anomaliesCount: number): string {
    if (anomaliesCount === 0) return "text-success";
    if (anomaliesCount < 3) return "text-amber-500";
    return "text-destructive";
  }
  
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Navbar />
        
        <main className="flex-1 bg-background p-6">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-2xl font-medium">Threat Detection</h1>
                <p className="text-muted-foreground">Monitor and manage potential identity theft threats</p>
              </div>
              <div className="mt-4 md:mt-0 flex items-center space-x-2">
                <div className={`text-lg font-medium ${getThreatStatusColor(unresolvedCount)}`}>
                  {unresolvedCount === 0 
                    ? "All Clear" 
                    : unresolvedCount === 1 
                      ? "1 Active Threat" 
                      : `${unresolvedCount} Active Threats`}
                </div>
                <Shield className={`h-5 w-5 ${getThreatStatusColor(unresolvedCount)}`} />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">High Risk</p>
                      <h3 className="text-2xl font-bold">{highRiskCount}</h3>
                    </div>
                    <div className="p-2 bg-red-100 rounded-full">
                      <AlertTriangle className="h-6 w-6 text-destructive" />
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground flex items-center">
                    {highRiskCount > 0 ? (
                      <>
                        <ArrowUpRight className="h-4 w-4 text-destructive mr-1" />
                        <span className="text-destructive font-medium">
                          {highRiskCount === 1 ? "1 threat" : `${highRiskCount} threats`}
                        </span>
                        <span className="ml-1">require immediate attention</span>
                      </>
                    ) : (
                      <>
                        <ArrowDownRight className="h-4 w-4 text-success mr-1" />
                        <span className="text-success font-medium">No threats</span>
                        <span className="ml-1">in this category</span>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Medium Risk</p>
                      <h3 className="text-2xl font-bold">{mediumRiskCount}</h3>
                    </div>
                    <div className="p-2 bg-amber-100 rounded-full">
                      <ShieldAlert className="h-6 w-6 text-amber-500" />
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground flex items-center">
                    {mediumRiskCount > 0 ? (
                      <>
                        <ArrowUpRight className="h-4 w-4 text-amber-500 mr-1" />
                        <span className="text-amber-500 font-medium">
                          {mediumRiskCount === 1 ? "1 threat" : `${mediumRiskCount} threats`}
                        </span>
                        <span className="ml-1">to review</span>
                      </>
                    ) : (
                      <>
                        <ArrowDownRight className="h-4 w-4 text-success mr-1" />
                        <span className="text-success font-medium">No threats</span>
                        <span className="ml-1">in this category</span>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Low Risk</p>
                      <h3 className="text-2xl font-bold">{lowRiskCount}</h3>
                    </div>
                    <div className="p-2 bg-blue-100 rounded-full">
                      <Shield className="h-6 w-6 text-blue-500" />
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground flex items-center">
                    {lowRiskCount > 0 ? (
                      <>
                        <ArrowUpRight className="h-4 w-4 text-blue-500 mr-1" />
                        <span className="text-blue-500 font-medium">
                          {lowRiskCount === 1 ? "1 item" : `${lowRiskCount} items`}
                        </span>
                        <span className="ml-1">for awareness</span>
                      </>
                    ) : (
                      <>
                        <ArrowDownRight className="h-4 w-4 text-success mr-1" />
                        <span className="text-success font-medium">No items</span>
                        <span className="ml-1">in this category</span>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Total Anomalies</p>
                      <h3 className="text-2xl font-bold">{anomalies?.length || 0}</h3>
                    </div>
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Fingerprint className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    <span className="font-medium">{
                      anomalies?.filter(a => a.status === "resolved").length || 0
                    } resolved</span> and <span className="font-medium">{unresolvedCount} active</span> anomalies detected
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Detected Anomalies</CardTitle>
                <CardDescription>
                  Review and respond to potential threats to your account security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="unresolved">Unresolved</TabsTrigger>
                    <TabsTrigger value="resolved">Resolved</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all">
                    {isLoading ? (
                      <div className="h-32 flex items-center justify-center">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : anomalies && anomalies.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Type</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Location</TableHead>
                            <TableHead>Risk Level</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {anomalies.map((anomaly) => (
                            <TableRow key={anomaly.id}>
                              <TableCell className="font-medium">
                                {anomaly.anomalyType.replace(/_/g, ' ')}
                              </TableCell>
                              <TableCell>
                                {formatDistanceToNow(new Date(anomaly.timestamp), { addSuffix: true })}
                              </TableCell>
                              <TableCell>{anomaly.location}</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    anomaly.riskLevel === "high" 
                                      ? "destructive" 
                                      : anomaly.riskLevel === "medium" 
                                        ? "default" 
                                        : "outline"
                                  }
                                  className="capitalize"
                                >
                                  {anomaly.riskLevel}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <span className={
                                  anomaly.status === "unresolved" 
                                    ? "text-destructive font-medium" 
                                    : "text-success font-medium"
                                }>
                                  {anomaly.status}
                                </span>
                              </TableCell>
                              <TableCell>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => showAnomalyDialog(anomaly)}
                                >
                                  Details
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Shield className="h-12 w-12 mx-auto mb-3 text-success" />
                        <h3 className="text-lg font-medium mb-1">No Anomalies Detected</h3>
                        <p>Your account activity looks normal. No suspicious activities have been detected.</p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="unresolved">
                    {isLoading ? (
                      <div className="h-32 flex items-center justify-center">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : anomalies && anomalies.filter(a => a.status === "unresolved").length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Type</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Location</TableHead>
                            <TableHead>Risk Level</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {anomalies.filter(a => a.status === "unresolved").map((anomaly) => (
                            <TableRow key={anomaly.id}>
                              <TableCell className="font-medium">
                                {anomaly.anomalyType.replace(/_/g, ' ')}
                              </TableCell>
                              <TableCell>
                                {formatDistanceToNow(new Date(anomaly.timestamp), { addSuffix: true })}
                              </TableCell>
                              <TableCell>{anomaly.location}</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    anomaly.riskLevel === "high" 
                                      ? "destructive" 
                                      : anomaly.riskLevel === "medium" 
                                        ? "default" 
                                        : "outline"
                                  }
                                  className="capitalize"
                                >
                                  {anomaly.riskLevel}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="mr-2"
                                  onClick={() => showAnomalyDialog(anomaly)}
                                >
                                  Details
                                </Button>
                                <Button 
                                  variant="default" 
                                  size="sm"
                                  onClick={() => handleResolveAnomaly(anomaly.id)}
                                >
                                  Resolve
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Shield className="h-12 w-12 mx-auto mb-3 text-success" />
                        <h3 className="text-lg font-medium mb-1">No Unresolved Anomalies</h3>
                        <p>All detected anomalies have been resolved.</p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="resolved">
                    {isLoading ? (
                      <div className="h-32 flex items-center justify-center">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : anomalies && anomalies.filter(a => a.status === "resolved").length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Type</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Location</TableHead>
                            <TableHead>Risk Level</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {anomalies.filter(a => a.status === "resolved").map((anomaly) => (
                            <TableRow key={anomaly.id}>
                              <TableCell className="font-medium">
                                {anomaly.anomalyType.replace(/_/g, ' ')}
                              </TableCell>
                              <TableCell>
                                {formatDistanceToNow(new Date(anomaly.timestamp), { addSuffix: true })}
                              </TableCell>
                              <TableCell>{anomaly.location}</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    anomaly.riskLevel === "high" 
                                      ? "destructive" 
                                      : anomaly.riskLevel === "medium" 
                                        ? "default" 
                                        : "outline"
                                  }
                                  className="capitalize"
                                >
                                  {anomaly.riskLevel}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => showAnomalyDialog(anomaly)}
                                >
                                  Details
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <AlertTriangle className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                        <h3 className="text-lg font-medium mb-1">No Resolved Anomalies</h3>
                        <p>You haven't resolved any anomalies yet.</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Threat Protection Tips</CardTitle>
                <CardDescription>
                  Follow these guidelines to enhance your protection against identity theft
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-success" />
                      <h3 className="font-medium">Strong Password Practices</h3>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 pl-7 list-disc">
                      <li>Use unique passwords for each account</li>
                      <li>Include a mix of characters, numbers, and symbols</li>
                      <li>Change passwords regularly, at least every 90 days</li>
                      <li>Consider using a password manager</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-success" />
                      <h3 className="font-medium">Two-Factor Authentication</h3>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 pl-7 list-disc">
                      <li>Enable 2FA on all your important accounts</li>
                      <li>Use authenticator apps instead of SMS when possible</li>
                      <li>Keep backup codes in a secure location</li>
                      <li>Regularly review your recovery options</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-success" />
                      <h3 className="font-medium">Safe Browsing Habits</h3>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 pl-7 list-disc">
                      <li>Always check URLs before clicking</li>
                      <li>Be cautious of unsolicited messages and emails</li>
                      <li>Never share personal information on untrusted sites</li>
                      <li>Keep your browser and devices updated</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
      
      {/* Anomaly Details Dialog */}
      <AlertDialog open={showAnomalyDetails} onOpenChange={setShowAnomalyDetails}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex items-center space-x-3">
              {selectedAnomaly && getAnomalyIcon(selectedAnomaly.anomalyType)}
              <AlertDialogTitle className="capitalize">
                {selectedAnomaly?.anomalyType.replace(/_/g, ' ')}
                {selectedAnomaly && getRiskBadge(selectedAnomaly.riskLevel)}
              </AlertDialogTitle>
            </div>
            <AlertDialogDescription className="space-y-4 pt-3">
              <p>{selectedAnomaly?.details}</p>
              
              <div className="bg-muted p-3 rounded-md space-y-2">
                <div className="grid grid-cols-2 gap-1 text-sm">
                  <span className="text-muted-foreground">Detected:</span>
                  <span className="font-medium">
                    {selectedAnomaly && formatDistanceToNow(new Date(selectedAnomaly.timestamp), { addSuffix: true })}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1 text-sm">
                  <span className="text-muted-foreground">Location:</span>
                  <span className="font-medium">{selectedAnomaly?.location}</span>
                </div>
                <div className="grid grid-cols-2 gap-1 text-sm">
                  <span className="text-muted-foreground">Status:</span>
                  <span className={`font-medium ${
                    selectedAnomaly?.status === "resolved" ? "text-success" : "text-destructive"
                  }`}>
                    {selectedAnomaly?.status}
                  </span>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Recommended Actions:</h4>
                <ul className="text-sm list-disc pl-5 space-y-1">
                  {selectedAnomaly?.riskLevel === "high" && (
                    <>
                      <li>Change your password immediately</li>
                      <li>Enable two-factor authentication if not already enabled</li>
                      <li>Review your recent account activity for other suspicious events</li>
                      <li>Contact support if you don't recognize this activity</li>
                    </>
                  )}
                  {selectedAnomaly?.riskLevel === "medium" && (
                    <>
                      <li>Verify if this activity was legitimate</li>
                      <li>Review your recent account activity</li>
                      <li>Consider updating your password as a precaution</li>
                    </>
                  )}
                  {selectedAnomaly?.riskLevel === "low" && (
                    <>
                      <li>No immediate action required if this was you</li>
                      <li>Mark as resolved if you recognize this activity</li>
                    </>
                  )}
                </ul>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
            {selectedAnomaly?.status === "unresolved" && (
              <AlertDialogAction onClick={() => selectedAnomaly && handleResolveAnomaly(selectedAnomaly.id)}>
                Mark as Resolved
              </AlertDialogAction>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
