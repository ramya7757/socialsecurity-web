import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, UserSearch, Shield, BarChart4, Search, AlertTriangle, Users, Activity } from "lucide-react";
import { User, UserActivity, Anomaly } from "@shared/schema";
import { Redirect } from "wouter";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format, formatDistanceToNow } from "date-fns";

export default function AdminPanel() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Redirect non-admin users
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }
  
  // Fetch all users
  const { data: users, isLoading: loadingUsers } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });
  
  // Filter users based on search query
  const filteredUsers = users?.filter(u => {
    if (!searchQuery) return true;
    return (
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.fullName && u.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });
  
  // User activity stats
  const totalUsers = users?.length || 0;
  const activeUsers = users?.filter(u => u.securityScore > 50).length || 0;
  const highRiskUsers = users?.filter(u => u.securityScore < 50).length || 0;
  
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Navbar />
        
        <main className="flex-1 bg-background p-6">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-2xl font-medium">Admin Panel</h1>
                <p className="text-muted-foreground">Manage users and monitor system security</p>
              </div>
              <div className="mt-4 md:mt-0">
                <div className="text-sm text-muted-foreground">
                  Admin Access: <span className="font-medium text-success">{user.username}</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Total Users</p>
                      <h3 className="text-2xl font-bold">{totalUsers}</h3>
                    </div>
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Active Users</p>
                      <h3 className="text-2xl font-bold">{activeUsers}</h3>
                    </div>
                    <div className="p-2 bg-success/10 rounded-full">
                      <Activity className="h-6 w-6 text-success" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">High Risk Users</p>
                      <h3 className="text-2xl font-bold">{highRiskUsers}</h3>
                    </div>
                    <div className="p-2 bg-destructive/10 rounded-full">
                      <AlertTriangle className="h-6 w-6 text-destructive" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>System Overview</CardTitle>
                <CardDescription>
                  Current status of the identity theft detection system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center mb-4">
                      <Shield className="h-5 w-5 mr-2 text-primary" />
                      <h3 className="font-medium">Security Status</h3>
                    </div>
                    <div className="text-3xl font-bold text-success mb-2">Normal</div>
                    <p className="text-sm text-muted-foreground">
                      No critical system issues detected
                    </p>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center mb-4">
                      <AlertTriangle className="h-5 w-5 mr-2 text-amber-500" />
                      <h3 className="font-medium">Active Threats</h3>
                    </div>
                    <div className="text-3xl font-bold text-amber-500 mb-2">12</div>
                    <p className="text-sm text-muted-foreground">
                      Unresolved anomalies across all users
                    </p>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center mb-4">
                      <BarChart4 className="h-5 w-5 mr-2 text-primary" />
                      <h3 className="font-medium">Detection Rate</h3>
                    </div>
                    <div className="text-3xl font-bold text-primary mb-2">97.8%</div>
                    <p className="text-sm text-muted-foreground">
                      Accuracy of anomaly detection model
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>
                  View and manage all users in the system
                </CardDescription>
                <div className="flex justify-between items-center mt-4">
                  <Tabs defaultValue="all" className="w-[400px]">
                    <TabsList>
                      <TabsTrigger value="all">All Users</TabsTrigger>
                      <TabsTrigger value="highrisk">High Risk</TabsTrigger>
                      <TabsTrigger value="admins">Admins</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search users..."
                      className="pl-8 w-[250px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loadingUsers ? (
                  <div className="h-64 flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : filteredUsers && filteredUsers.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Full Name</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Security Score</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.fullName || "—"}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === "admin" ? "default" : "outline"}>
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <div
                                className={`h-2.5 w-2.5 rounded-full mr-2 ${
                                  user.securityScore >= 80 
                                    ? "bg-success" 
                                    : user.securityScore >= 50 
                                      ? "bg-amber-500" 
                                      : "bg-destructive"
                                }`}
                              />
                              <span>{user.securityScore}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {formatDistanceToNow(new Date(user.createdAt), { addSuffix: true })}
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" className="mr-2">
                              <UserSearch className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <UserSearch className="h-12 w-12 mx-auto mb-3" />
                    <h3 className="text-lg font-medium mb-1">No Users Found</h3>
                    <p>Try adjusting your search criteria.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
