import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import SecurityScore from "@/components/dashboard/security-score";
import BehaviorSummary from "@/components/dashboard/behavior-summary";
import ActivityTimeline from "@/components/dashboard/activity-timeline";
import BehavioralPattern from "@/components/dashboard/behavioral-pattern";
import AnomalyDetection from "@/components/dashboard/anomaly-detection";
import DeviceSecurity from "@/components/dashboard/device-security";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Anomaly } from "@shared/schema";
import { AlertTriangle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Lock, UserCheck } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  
  // Fetch user anomalies for alert banner
  const { data: anomalies } = useQuery<Anomaly[]>({
    queryKey: ["/api/user/anomalies"],
  });
  
  const unresolvedAnomalies = anomalies?.filter(a => a.status === "unresolved" && a.riskLevel === "high") || [];
  const [showAlert, setShowAlert] = useState(true);
  
  const handleResolveAnomaly = async (id: number, userConfirmed: boolean) => {
    await apiRequest("PATCH", `/api/user/anomalies/${id}`, { 
      status: "resolved",
      details: userConfirmed ? "User confirmed this was them" : "User confirmed this was not them"
    });
    queryClient.invalidateQueries({ queryKey: ["/api/user/anomalies"] });
    setShowAlert(false);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow bg-background">
        <div className="container mx-auto px-4 py-6">
          {/* Alert Banner */}
          {showAlert && unresolvedAnomalies.length > 0 && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-5 w-5 mr-2" />
              <div className="flex-1">
                <AlertTitle>Suspicious Activity Detected</AlertTitle>
                <AlertDescription>
                  {unresolvedAnomalies[0].details || "Unusual activity detected on your account."}
                </AlertDescription>
              </div>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-white text-destructive border-white hover:bg-white/90 hover:text-destructive"
                  onClick={() => handleResolveAnomaly(unresolvedAnomalies[0].id, false)}
                >
                  Not Me
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="text-white hover:bg-white/20"
                  onClick={() => handleResolveAnomaly(unresolvedAnomalies[0].id, true)}
                >
                  Yes, It's Me
                </Button>
              </div>
            </Alert>
          )}

          {/* Dashboard Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h1 className="text-2xl font-medium">User Dashboard</h1>
              <p className="text-muted-foreground">Monitor your account activity and security status</p>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="flex space-x-2 items-center">
                <span className="inline-flex px-3 py-1 rounded-full text-sm font-medium bg-success text-success-foreground">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                  Protected
                </span>
                <span className="text-sm text-muted-foreground">Last scan: Today, {new Date().toLocaleTimeString()}</span>
              </div>
            </div>
          </div>

          {/* Security Score and Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
            {/* Security Score */}
            <div className="lg:col-span-1">
              <SecurityScore />
            </div>

            {/* Behavior Summary */}
            <div className="lg:col-span-3">
              <BehaviorSummary />
            </div>
          </div>

          {/* Behavior Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Activity Timeline */}
            <ActivityTimeline />

            {/* Behavioral Pattern */}
            <BehavioralPattern />
          </div>

          {/* Anomaly Detection & Device Security */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Anomaly Detection */}
            <div className="lg:col-span-2">
              <AnomalyDetection />
            </div>

            {/* Device Security */}
            <DeviceSecurity />
          </div>

          {/* Educational Section */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-lg font-medium">Identity Theft Education</h2>
                <Link href="/education">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View All Resources
                  </Button>
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border border-border rounded-lg card-hover">
                  <div className="text-primary text-3xl mb-3">
                    <Shield className="h-8 w-8" />
                  </div>
                  <h3 className="font-medium mb-2">How to Recognize Phishing</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Learn how to identify and avoid common phishing attempts targeting social media users.
                  </p>
                  <Link href="/education/1">
                    <a className="text-sm text-primary hover:underline">Read More →</a>
                  </Link>
                </div>
                <div className="p-4 border border-border rounded-lg card-hover">
                  <div className="text-primary text-3xl mb-3">
                    <Lock className="h-8 w-8" />
                  </div>
                  <h3 className="font-medium mb-2">Password Best Practices</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Create strong, unique passwords and manage them securely with these essential tips.
                  </p>
                  <Link href="/education/2">
                    <a className="text-sm text-primary hover:underline">Read More →</a>
                  </Link>
                </div>
                <div className="p-4 border border-border rounded-lg card-hover">
                  <div className="text-primary text-3xl mb-3">
                    <UserCheck className="h-8 w-8" />
                  </div>
                  <h3 className="font-medium mb-2">What to Do If Compromised</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Step-by-step guide on how to recover from identity theft and secure your accounts.
                  </p>
                  <Link href="/education/3">
                    <a className="text-sm text-primary hover:underline">Read More →</a>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Simulation Environment Preview */}
          <Card className="mb-6 overflow-hidden">
            <div className="bg-primary text-primary-foreground p-4">
              <h2 className="text-lg font-medium">Simulation Environment</h2>
              <p className="text-sm">Test your identity theft detection knowledge with interactive scenarios</p>
            </div>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-3">Test Your Detection Skills</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our simulation environment allows you to practice identifying identity theft attempts in a safe, controlled setting. Try different scenarios and learn how to protect yourself.
                  </p>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-success mr-2">
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                      <span className="text-sm">Realistic social media scenarios</span>
                    </div>
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-success mr-2">
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                      <span className="text-sm">Learn to spot suspicious behavior</span>
                    </div>
                    <div className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-success mr-2">
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                      <span className="text-sm">Improve your security awareness</span>
                    </div>
                  </div>
                  <Link href="/simulation">
                    <Button className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                        <circle cx="12" cy="12" r="10" />
                        <polygon points="10 8 16 12 10 16 10 8" />
                      </svg>
                      Start Simulation
                    </Button>
                  </Link>
                </div>
                <div className="bg-muted rounded-lg p-4 border">
                  <div className="mb-3 font-medium">Sample Scenario Preview</div>
                  <div className="p-3 bg-background rounded border mb-3">
                    <div className="flex items-start">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2 shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                          <path d="M18 20a6 6 0 0 0-12 0"></path>
                          <circle cx="12" cy="10" r="4"></circle>
                          <circle cx="12" cy="12" r="10"></circle>
                        </svg>
                      </div>
                      <div>
                        <div className="font-medium">Sarah Johnson</div>
                        <div className="text-xs text-muted-foreground">2 hours ago</div>
                        <div className="text-sm mt-1">
                          Hi there! I'm having trouble accessing our shared document. Could you send me your login details so I can check if it's a permission issue?
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-sm">Is this a potential identity theft attempt?</div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Button variant="destructive" size="sm">Yes, it's suspicious</Button>
                    <Button variant="secondary" size="sm">No, it's legitimate</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
