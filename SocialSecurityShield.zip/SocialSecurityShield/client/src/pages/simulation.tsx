import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/sidebar";
import ScenarioCard from "@/components/simulation/scenario-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SimulationScenario } from "@shared/schema";
import { Loader2, Award, BookOpen, Brain, Target } from "lucide-react";

export default function Simulation() {
  const [filter, setFilter] = useState<string>("all");
  
  const { data: scenarios, isLoading } = useQuery<SimulationScenario[]>({
    queryKey: ["/api/simulation"],
  });
  
  // Filter scenarios based on difficulty
  const filteredScenarios = scenarios?.filter(scenario => {
    if (filter === "all") return true;
    return scenario.difficulty === filter;
  });
  
  const completedScenariosCount = 0; // In a real app, this would come from user progress
  const totalScenariosCount = scenarios?.length || 0;
  const completionPercentage = totalScenariosCount > 0 
    ? Math.round((completedScenariosCount / totalScenariosCount) * 100) 
    : 0;
  
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Navbar />
        
        <main className="flex-1 bg-background p-6">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-2xl font-medium">Simulation Environment</h1>
                <p className="text-muted-foreground">Practice identifying identity theft attempts in simulated scenarios</p>
              </div>
              <div className="mt-4 md:mt-0">
                <Button variant="outline" className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4 mr-2" />
                  <span>View Tutorial</span>
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="col-span-1 md:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle>Your Progress</CardTitle>
                  <CardDescription>
                    Track your advancement through the simulation scenarios
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-medium">
                      {completedScenariosCount} of {totalScenariosCount} scenarios completed
                    </span>
                    <span className="text-sm font-medium">{completionPercentage}%</span>
                  </div>
                  <Progress value={completionPercentage} className="h-2" />
                  
                  <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-md">
                      <div className="text-2xl font-bold">{
                        scenarios?.filter(s => s.difficulty === "easy").length || 0
                      }</div>
                      <Badge className="mt-1 bg-success">Easy</Badge>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-md">
                      <div className="text-2xl font-bold">{
                        scenarios?.filter(s => s.difficulty === "medium").length || 0
                      }</div>
                      <Badge className="mt-1 bg-primary">Medium</Badge>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-md">
                      <div className="text-2xl font-bold">{
                        scenarios?.filter(s => s.difficulty === "hard").length || 0
                      }</div>
                      <Badge className="mt-1 bg-destructive">Hard</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Detection Skills</CardTitle>
                  <CardDescription>Your ability to identify threats</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Brain className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm">Phishing Detection</span>
                      </div>
                      <div className="relative w-16 h-16">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-lg font-bold">70%</span>
                        </div>
                        <svg viewBox="0 0 36 36" className="h-16 w-16 transform -rotate-90">
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--muted))"
                            strokeWidth="2"
                            className="stroke-current"
                          />
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="2"
                            strokeDasharray="100, 100"
                            strokeDashoffset="30"
                            className="stroke-current"
                          />
                        </svg>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Target className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm">Impostor Recognition</span>
                      </div>
                      <div className="relative w-16 h-16">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-lg font-bold">85%</span>
                        </div>
                        <svg viewBox="0 0 36 36" className="h-16 w-16 transform -rotate-90">
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--muted))"
                            strokeWidth="2"
                            className="stroke-current"
                          />
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="2"
                            strokeDasharray="100, 100"
                            strokeDashoffset="15"
                            className="stroke-current"
                          />
                        </svg>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Award className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm">Overall Score</span>
                      </div>
                      <div className="relative w-16 h-16">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-lg font-bold">78%</span>
                        </div>
                        <svg viewBox="0 0 36 36" className="h-16 w-16 transform -rotate-90">
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--muted))"
                            strokeWidth="2"
                            className="stroke-current"
                          />
                          <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="2"
                            strokeDasharray="100, 100"
                            strokeDashoffset="22"
                            className="stroke-current"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Simulation Scenarios</CardTitle>
                <CardDescription>
                  Test your ability to identify identity theft attempts in these scenarios
                </CardDescription>
                <Tabs defaultValue="all" className="mt-2" onValueChange={setFilter}>
                  <TabsList>
                    <TabsTrigger value="all">All Scenarios</TabsTrigger>
                    <TabsTrigger value="easy">Easy</TabsTrigger>
                    <TabsTrigger value="medium">Medium</TabsTrigger>
                    <TabsTrigger value="hard">Hard</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="h-48 flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : filteredScenarios && filteredScenarios.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredScenarios.map((scenario) => (
                      <ScenarioCard key={scenario.id} scenario={scenario} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <BookOpen className="h-12 w-12 mx-auto mb-3" />
                    <h3 className="text-lg font-medium mb-1">No Scenarios Available</h3>
                    <p>There are no scenarios matching the selected filter.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
