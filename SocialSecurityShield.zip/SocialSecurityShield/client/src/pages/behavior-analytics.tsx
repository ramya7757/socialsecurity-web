import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Loader2, Download, Calendar } from "lucide-react";
import { UserActivity, UserSession } from "@shared/schema";
import { 
  Chart, 
  LineController, 
  LineElement, 
  PointElement, 
  LinearScale, 
  CategoryScale, 
  Legend, 
  Tooltip,
  BarController,
  BarElement,
  RadarController,
  RadialLinearScale,
  PolarAreaController,
  ArcElement
} from "chart.js";

// Register Chart.js components
Chart.register(
  LineController, 
  LineElement, 
  PointElement, 
  LinearScale, 
  CategoryScale, 
  Legend, 
  Tooltip,
  BarController,
  BarElement,
  RadarController,
  RadialLinearScale,
  PolarAreaController,
  ArcElement
);

export default function BehaviorAnalytics() {
  const [timeRange, setTimeRange] = useState("7");
  
  // Fetch user activities and sessions
  const { data: activities, isLoading: loadingActivities } = useQuery<UserActivity[]>({
    queryKey: ["/api/user/activities", timeRange],
  });
  
  const { data: sessions, isLoading: loadingSessions } = useQuery<UserSession[]>({
    queryKey: ["/api/user/sessions", timeRange],
  });
  
  // Chart refs and instances
  const loginTimeChartRef = useRef<HTMLCanvasElement>(null);
  const loginTimeChartInstance = useRef<Chart | null>(null);
  
  const sessionDurationChartRef = useRef<HTMLCanvasElement>(null);
  const sessionDurationChartInstance = useRef<Chart | null>(null);
  
  const activityTypeChartRef = useRef<HTMLCanvasElement>(null);
  const activityTypeChartInstance = useRef<Chart | null>(null);
  
  const locationChartRef = useRef<HTMLCanvasElement>(null);
  const locationChartInstance = useRef<Chart | null>(null);
  
  // Set up login time chart
  useEffect(() => {
    if (!loginTimeChartRef.current || !sessions || sessions.length === 0) return;
    
    // Destroy existing chart if it exists
    if (loginTimeChartInstance.current) {
      loginTimeChartInstance.current.destroy();
    }
    
    const ctx = loginTimeChartRef.current.getContext("2d");
    if (!ctx) return;
    
    // Process session data to get login hours
    const loginHours = sessions.map(session => new Date(session.loginTime).getHours());
    
    // Count occurrences of each hour
    const hourCounts = Array(24).fill(0);
    loginHours.forEach(hour => hourCounts[hour]++);
    
    // Create labels for 24-hour format
    const hourLabels = Array.from({ length: 24 }, (_, i) => 
      i.toString().padStart(2, '0') + ':00'
    );
    
    loginTimeChartInstance.current = new Chart(ctx, {
      type: "line",
      data: {
        labels: hourLabels,
        datasets: [
          {
            label: "Login Times",
            data: hourCounts,
            borderColor: "hsl(var(--primary))",
            backgroundColor: "hsl(var(--primary) / 0.1)",
            fill: true,
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Number of Logins"
            }
          },
          x: {
            title: {
              display: true,
              text: "Hour of Day"
            }
          }
        }
      }
    });
    
    return () => {
      if (loginTimeChartInstance.current) {
        loginTimeChartInstance.current.destroy();
      }
    };
  }, [sessions]);
  
  // Set up session duration chart
  useEffect(() => {
    if (!sessionDurationChartRef.current || !sessions || sessions.length === 0) return;
    
    // Destroy existing chart if it exists
    if (sessionDurationChartInstance.current) {
      sessionDurationChartInstance.current.destroy();
    }
    
    const ctx = sessionDurationChartRef.current.getContext("2d");
    if (!ctx) return;
    
    // Process session data to get durations in minutes
    const durations = sessions
      .filter(session => session.duration !== null)
      .map(session => (session.duration || 0) / 60); // Convert seconds to minutes
    
    // Create duration ranges
    const ranges = ["0-15", "15-30", "30-60", "60-120", "120+"];
    const durationCounts = [0, 0, 0, 0, 0];
    
    durations.forEach(duration => {
      if (duration <= 15) durationCounts[0]++;
      else if (duration <= 30) durationCounts[1]++;
      else if (duration <= 60) durationCounts[2]++;
      else if (duration <= 120) durationCounts[3]++;
      else durationCounts[4]++;
    });
    
    sessionDurationChartInstance.current = new Chart(ctx, {
      type: "bar",
      data: {
        labels: ranges,
        datasets: [
          {
            label: "Session Duration (minutes)",
            data: durationCounts,
            backgroundColor: [
              "hsl(var(--primary))",
              "hsl(var(--secondary))",
              "hsl(var(--accent))",
              "hsl(var(--success))",
              "hsl(var(--muted-foreground))"
            ],
            borderWidth: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Number of Sessions"
            }
          },
          x: {
            title: {
              display: true,
              text: "Duration (minutes)"
            }
          }
        }
      }
    });
    
    return () => {
      if (sessionDurationChartInstance.current) {
        sessionDurationChartInstance.current.destroy();
      }
    };
  }, [sessions]);
  
  // Set up activity type chart
  useEffect(() => {
    if (!activityTypeChartRef.current || !activities || activities.length === 0) return;
    
    // Destroy existing chart if it exists
    if (activityTypeChartInstance.current) {
      activityTypeChartInstance.current.destroy();
    }
    
    const ctx = activityTypeChartRef.current.getContext("2d");
    if (!ctx) return;
    
    // Count activity types
    const activityTypes = activities.reduce((acc, activity) => {
      acc[activity.activityType] = (acc[activity.activityType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const labels = Object.keys(activityTypes);
    const data = Object.values(activityTypes);
    
    activityTypeChartInstance.current = new Chart(ctx, {
      type: "polarArea",
      data: {
        labels,
        datasets: [
          {
            data,
            backgroundColor: [
              "hsl(var(--primary))",
              "hsl(var(--secondary))",
              "hsl(var(--accent))",
              "hsl(var(--success))",
              "hsl(var(--destructive))"
            ],
            borderWidth: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      }
    });
    
    return () => {
      if (activityTypeChartInstance.current) {
        activityTypeChartInstance.current.destroy();
      }
    };
  }, [activities]);
  
  // Set up location chart
  useEffect(() => {
    if (!locationChartRef.current || !sessions || sessions.length === 0) return;
    
    // Destroy existing chart if it exists
    if (locationChartInstance.current) {
      locationChartInstance.current.destroy();
    }
    
    const ctx = locationChartRef.current.getContext("2d");
    if (!ctx) return;
    
    // Count locations
    const locations = sessions.reduce((acc, session) => {
      const location = session.location || "Unknown";
      acc[location] = (acc[location] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const labels = Object.keys(locations);
    const data = Object.values(locations);
    
    locationChartInstance.current = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels,
        datasets: [
          {
            data,
            backgroundColor: [
              "hsl(var(--primary))",
              "hsl(var(--secondary))",
              "hsl(var(--accent))",
              "hsl(var(--success))",
              "hsl(var(--destructive))"
            ],
            borderWidth: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      }
    });
    
    return () => {
      if (locationChartInstance.current) {
        locationChartInstance.current.destroy();
      }
    };
  }, [sessions]);
  
  const isLoading = loadingActivities || loadingSessions;
  
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Navbar />
        
        <main className="flex-1 bg-background p-6">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-2xl font-medium">Behavior Analytics</h1>
                <p className="text-muted-foreground">Analyze your account usage patterns and behaviors</p>
              </div>
              <div className="mt-4 md:mt-0 flex space-x-2">
                <Select defaultValue={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-[150px]">
                    <Calendar className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Select range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last year</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export Data
                </Button>
              </div>
            </div>
            
            <Tabs defaultValue="login-patterns" className="space-y-4">
              <TabsList className="grid w-full md:w-auto grid-cols-2 md:grid-cols-4 gap-2">
                <TabsTrigger value="login-patterns">Login Patterns</TabsTrigger>
                <TabsTrigger value="session-data">Session Data</TabsTrigger>
                <TabsTrigger value="activity-types">Activity Types</TabsTrigger>
                <TabsTrigger value="location-analysis">Location Analysis</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login-patterns">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="col-span-2">
                    <CardHeader>
                      <CardTitle>Login Time Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="h-80 flex items-center justify-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                      ) : (
                        <div className="h-80">
                          <canvas ref={loginTimeChartRef}></canvas>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Login Pattern Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-1">Most Active Hours</h3>
                          <p className="text-sm text-muted-foreground">
                            You typically log in between 9:00 AM and 5:00 PM, which is consistent with business hours.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Unusual Login Time</h3>
                          <p className="text-sm text-muted-foreground">
                            A login at 3:42 AM was detected, which is outside your normal pattern. This may be worth investigating.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Weekday vs Weekend</h3>
                          <p className="text-sm text-muted-foreground">
                            Your login activity drops by 76% on weekends compared to weekdays.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="session-data">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="col-span-2">
                    <CardHeader>
                      <CardTitle>Session Duration Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="h-80 flex items-center justify-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                      ) : (
                        <div className="h-80">
                          <canvas ref={sessionDurationChartRef}></canvas>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Session Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-1">Average Session Length</h3>
                          <p className="text-sm text-muted-foreground">
                            Your average session duration is {
                              sessions && sessions.length > 0 
                                ? ((sessions.reduce((sum, s) => sum + (s.duration || 0), 0) / sessions.length) / 60).toFixed(1)
                                : "0"
                            } minutes.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Long Sessions</h3>
                          <p className="text-sm text-muted-foreground">
                            {
                              sessions?.filter(s => (s.duration || 0) > 7200).length || 0
                            } sessions exceeded 2 hours in the selected period.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Short Sessions</h3>
                          <p className="text-sm text-muted-foreground">
                            {
                              sessions?.filter(s => (s.duration || 0) < 300).length || 0
                            } sessions were less than 5 minutes, which might indicate quick checks or abandoned sessions.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="activity-types">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="col-span-2">
                    <CardHeader>
                      <CardTitle>Activity Type Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="h-80 flex items-center justify-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                      ) : (
                        <div className="h-80">
                          <canvas ref={activityTypeChartRef}></canvas>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Activity Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-1">Most Common Activity</h3>
                          <p className="text-sm text-muted-foreground">
                            "Login" is your most frequent activity type, accounting for {
                              activities 
                                ? Math.round((activities.filter(a => a.activityType === "login").length / activities.length) * 100)
                                : 0
                            }% of all actions.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Security Events</h3>
                          <p className="text-sm text-muted-foreground">
                            {
                              activities?.filter(a => 
                                a.activityType === "password_change" || 
                                a.activityType === "login_failed"
                              ).length || 0
                            } security-related events were recorded in the selected time period.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Activity Trend</h3>
                          <p className="text-sm text-muted-foreground">
                            Your overall activity level has increased by 12% compared to the previous period.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="location-analysis">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="col-span-2">
                    <CardHeader>
                      <CardTitle>Login Locations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="h-80 flex items-center justify-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                      ) : (
                        <div className="h-80">
                          <canvas ref={locationChartRef}></canvas>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Location Insights</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-1">Primary Location</h3>
                          <p className="text-sm text-muted-foreground">
                            {
                              sessions && sessions.length > 0
                                ? (() => {
                                    const locations = sessions.reduce((acc, s) => {
                                      const loc = s.location || "Unknown";
                                      acc[loc] = (acc[loc] || 0) + 1;
                                      return acc;
                                    }, {} as Record<string, number>);
                                    const primaryLocation = Object.entries(locations).sort((a, b) => b[1] - a[1])[0];
                                    return primaryLocation ? primaryLocation[0] : "Unknown";
                                  })()
                                : "Unknown"
                            } is your most common login location.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">New Locations</h3>
                          <p className="text-sm text-muted-foreground">
                            {
                              sessions && sessions.length > 0
                                ? (() => {
                                    // Get unique locations
                                    const locations = new Set(sessions.map(s => s.location || "Unknown"));
                                    return locations.size;
                                  })()
                                : 0
                            } unique locations detected in the selected period.
                          </p>
                        </div>
                        <div>
                          <h3 className="font-medium mb-1">Location Risk</h3>
                          <p className="text-sm text-muted-foreground">
                            No high-risk locations detected in your login history.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
