import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/sidebar";
import EducationCard from "@/components/education/education-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EducationalResource } from "@shared/schema";
import { Loader2, Search, BookOpen, Shield, Lock, UserCheck, AlertTriangle, FileText } from "lucide-react";
import { useParams, useLocation } from "wouter";

export default function Education() {
  const [location, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [category, setCategory] = useState("all");
  
  const { data: resources, isLoading } = useQuery<EducationalResource[]>({
    queryKey: ["/api/education"],
  });
  
  // Filter resources based on category and search query
  const filteredResources = resources?.filter(resource => {
    const matchesCategory = category === "all" || resource.category === category;
    const matchesSearch = searchQuery === "" || 
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });
  
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <Navbar />
        
        <main className="flex-1 bg-background p-6">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-2xl font-medium">Educational Resources</h1>
                <p className="text-muted-foreground">Learn how to protect yourself from identity theft</p>
              </div>
              <div className="mt-4 md:mt-0 flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search resources..."
                    className="pl-8 w-full md:w-[250px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Featured Articles</CardTitle>
                <CardDescription>
                  Top resources to help you understand and prevent identity theft
                </CardDescription>
                <Tabs defaultValue="all" className="mt-2" onValueChange={setCategory}>
                  <TabsList>
                    <TabsTrigger value="all">All Topics</TabsTrigger>
                    <TabsTrigger value="security">Security</TabsTrigger>
                    <TabsTrigger value="privacy">Privacy</TabsTrigger>
                    <TabsTrigger value="recovery">Recovery</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="h-48 flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : filteredResources && filteredResources.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredResources.map((resource) => (
                      <EducationCard key={resource.id} resource={resource} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-3" />
                    <h3 className="text-lg font-medium mb-1">No Resources Found</h3>
                    <p>Try adjusting your search or filters to find what you're looking for.</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Tips</CardTitle>
                  <CardDescription>
                    Essential advice to protect your online identity
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex">
                    <div className="flex-shrink-0 mr-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Shield className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Enable Two-Factor Authentication</h3>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your accounts by requiring a second form of verification.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Lock className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Use Strong, Unique Passwords</h3>
                      <p className="text-sm text-muted-foreground">
                        Create complex passwords and avoid reusing them across different platforms.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <UserCheck className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Regularly Review Your Privacy Settings</h3>
                      <p className="text-sm text-muted-foreground">
                        Check and update your privacy settings on social networks and other platforms regularly.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Be Cautious With Personal Information</h3>
                      <p className="text-sm text-muted-foreground">
                        Think twice before sharing personal details online, especially in public forums.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Identity Theft Warning Signs</CardTitle>
                  <CardDescription>
                    Learn to recognize the red flags of identity theft
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-md bg-muted/50">
                      <h3 className="font-medium text-destructive flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Unexpected Account Activity
                      </h3>
                      <p className="text-sm mt-1">
                        Unexplained withdrawals, charges, or purchases on your accounts that you didn't make.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-md bg-muted/50">
                      <h3 className="font-medium text-destructive flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Missing Mail or Bills
                      </h3>
                      <p className="text-sm mt-1">
                        Not receiving expected bills or other mail could mean someone has changed your address.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-md bg-muted/50">
                      <h3 className="font-medium text-destructive flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Unfamiliar Accounts
                      </h3>
                      <p className="text-sm mt-1">
                        Accounts or charges on your credit report that you don't recognize.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-md bg-muted/50">
                      <h3 className="font-medium text-destructive flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Denied Credit for No Reason
                      </h3>
                      <p className="text-sm mt-1">
                        Being denied credit unexpectedly despite having good credit history.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <div className="relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-primary/10 rounded-lg z-0"></div>
                <CardContent className="relative z-10 p-6 md:p-8">
                  <div className="grid md:grid-cols-2 gap-6 items-center">
                    <div>
                      <h2 className="text-2xl font-medium mb-2">Identity Theft Protection Workshop</h2>
                      <p className="text-muted-foreground mb-4">
                        Join our comprehensive online workshop to learn advanced techniques for protecting your digital identity. Sessions include live demonstrations and interactive Q&A with security experts.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-3">
                        <Button size="lg">
                          <BookOpen className="mr-2 h-4 w-4" />
                          Register Now
                        </Button>
                        <Button variant="outline" size="lg">
                          Learn More
                        </Button>
                      </div>
                    </div>
                    <div className="flex justify-center">
                      <Shield className="h-48 w-48 text-primary/20" />
                    </div>
                  </div>
                </CardContent>
              </div>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
