import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("user").notNull(),
  securityScore: integer("security_score").default(70),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  browser: text("browser"),
  os: text("os"),
  device: text("device"),
  location: text("location"),
  loginTime: timestamp("login_time").defaultNow().notNull(),
  logoutTime: timestamp("logout_time"),
  duration: integer("duration"),
  isActive: boolean("is_active").default(true),
});

export const insertSessionSchema = createInsertSchema(userSessions).pick({
  userId: true,
  ipAddress: true,
  userAgent: true,
  browser: true,
  os: true,
  device: true,
  location: true,
});

export const userActivities = pgTable("user_activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  sessionId: integer("session_id"),
  activityType: text("activity_type").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(userActivities).pick({
  userId: true,
  sessionId: true,
  activityType: true,
  details: true,
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  deviceName: text("device_name").notNull(),
  deviceType: text("device_type").notNull(),
  isTrusted: boolean("is_trusted").default(true),
  isPrimary: boolean("is_primary").default(false),
  lastActive: timestamp("last_active").defaultNow().notNull(),
});

export const insertDeviceSchema = createInsertSchema(devices).pick({
  userId: true,
  deviceName: true,
  deviceType: true,
  isTrusted: true,
  isPrimary: true,
});

export const anomalies = pgTable("anomalies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  sessionId: integer("session_id"),
  anomalyType: text("anomaly_type").notNull(),
  details: text("details"),
  riskLevel: text("risk_level").notNull(),
  status: text("status").default("unresolved").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  location: text("location"),
});

export const insertAnomalySchema = createInsertSchema(anomalies).pick({
  userId: true,
  sessionId: true,
  anomalyType: true,
  details: true,
  riskLevel: true,
  status: true,
  location: true,
});

export const educationalResources = pgTable("educational_resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(),
});

export const insertEducationalResourceSchema = createInsertSchema(educationalResources).pick({
  title: true,
  description: true,
  content: true,
  icon: true,
  category: true,
});

export const simulationScenarios = pgTable("simulation_scenarios", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  correctAnswer: boolean("correct_answer").notNull(),
  explanation: text("explanation").notNull(),
  difficulty: text("difficulty").notNull(),
});

export const insertSimulationScenarioSchema = createInsertSchema(simulationScenarios).pick({
  title: true,
  description: true,
  content: true,
  correctAnswer: true,
  explanation: true,
  difficulty: true,
});

export const socialAccounts = pgTable("social_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  provider: text("provider").notNull(), // 'instagram', 'facebook', 'snapchat', etc.
  providerId: text("provider_id").notNull(), // The ID on the provider's platform
  username: text("username"), // Username on that platform
  profileUrl: text("profile_url"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSocialAccountSchema = createInsertSchema(socialAccounts).pick({
  userId: true,
  provider: true,
  providerId: true,
  username: true,
  profileUrl: true,
  accessToken: true,
  refreshToken: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;

export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserSession = z.infer<typeof insertSessionSchema>;

export type UserActivity = typeof userActivities.$inferSelect;
export type InsertUserActivity = z.infer<typeof insertActivitySchema>;

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type Anomaly = typeof anomalies.$inferSelect;
export type InsertAnomaly = z.infer<typeof insertAnomalySchema>;

export type EducationalResource = typeof educationalResources.$inferSelect;
export type InsertEducationalResource = z.infer<typeof insertEducationalResourceSchema>;

export type SimulationScenario = typeof simulationScenarios.$inferSelect;
export type InsertSimulationScenario = z.infer<typeof insertSimulationScenarioSchema>;

export type SocialAccount = typeof socialAccounts.$inferSelect;
export type InsertSocialAccount = z.infer<typeof insertSocialAccountSchema>;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(userSessions),
  activities: many(userActivities),
  devices: many(devices),
  anomalies: many(anomalies),
  socialAccounts: many(socialAccounts),
}));

export const userSessionsRelations = relations(userSessions, ({ one, many }) => ({
  user: one(users, {
    fields: [userSessions.userId],
    references: [users.id],
  }),
  activities: many(userActivities),
  anomalies: many(anomalies),
}));

export const userActivitiesRelations = relations(userActivities, ({ one }) => ({
  user: one(users, {
    fields: [userActivities.userId],
    references: [users.id],
  }),
  session: one(userSessions, {
    fields: [userActivities.sessionId],
    references: [userSessions.id],
  }),
}));

export const devicesRelations = relations(devices, ({ one }) => ({
  user: one(users, {
    fields: [devices.userId],
    references: [users.id],
  }),
}));

export const anomaliesRelations = relations(anomalies, ({ one }) => ({
  user: one(users, {
    fields: [anomalies.userId],
    references: [users.id],
  }),
  session: one(userSessions, {
    fields: [anomalies.sessionId],
    references: [userSessions.id],
  }),
}));

export const socialAccountsRelations = relations(socialAccounts, ({ one }) => ({
  user: one(users, {
    fields: [socialAccounts.userId],
    references: [users.id],
  }),
}));
